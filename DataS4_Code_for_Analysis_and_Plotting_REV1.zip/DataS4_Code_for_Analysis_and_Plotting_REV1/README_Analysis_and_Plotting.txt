This README applies to a series of data analysis code files. 		
		
1) Spatial_Coverage.R: This file reads in raw spreadsheets that have latitude and longitude coordinates and calculates metrics of how evenly sampled the city is. To do so, cities are divided into grids and the percentage of empty grid cells is calculated, as well as the skew and kurtosis of the distribution of number of trees per cell (excluding empty cells). It generates the following files:		
	A) SpatialCoverage_Summary_Data.csv, which includes metrics of coverage (percent_cells_empty; for high values, only certain parts of the city were sampled while no trees were sampled in other regions) and evenness (skew_occupied_cells, kurtosis_occupied_cells which identify the degree to which the sampled data diverges from a normal distribution. Skew indicates symmetry, and values outside of [-3,3] are considered skewed; kurtosis indicates how heavy the tails are, and values outside of [-8,8] are considered heavy-tailed.)	
	B) SpatialCoverage_Raw_Data.csv, which includes the number of trees (raw and adjusted for area) per grid cell for each city.	
	C) CoveragePlots.zip, coverage plots for all cities showing spatial distribution of trees on a background of the city divided into a grid.	
		
2) Analysis_Raw_Datasheets.R : this file reads in the raw datasheets, 63 city files where every row is a tree with information about that tree, and does two things. First, it generates a summary .csv with city-specific information on nativity, biodiversity, environmental variables, social variables, and more. This includes estimates of sample coverage, asymptotic estimates of species richness and effective species numbers, and rarefaction / extrapolation to calculate these metrics of diversity for a standard population size (to enable comparison among cities). Second, it calculates weighted comparisons of species compositions between cities. It generates the following files:		
	A)City_Data_Diversity_Enviroment_Social.csv, which will be used later in Models.R and Plotting.R . 	
	B) 9 files on different metrics to compare species compositions, which will be used later in Models.R:  	
		ChiSquare_Distances_Species_Composition_ALL.csv;
		ChiSquare_Distances_Species_Composition_NATIVE.csv;
		ChiSquare_Distances_Species_Composition_NONNATIVE.csv;
		Euclidean_Distances_Species_Composition_ALL.csv;
		Euclidean_Distances_Species_Composition_NATIVE.csv;
		Euclidean_Distances_Species_Composition_NONNATIVE.csv;
		DiceSorenson_Scores_Species_Composition_ALL.csv;
		DiceSorenson_Scores_Species_Composition_NATIVE.csv;
		DiceSorenson_Scores_Species_Composition_NONNATIVE.csv
		
3) Park_vs_Urban.R : this file reads in the raw datasheets, 63 city files where every row is a tree, and calculates the biodiversity (and abundance of native trees) in parks vs. that of urban areas. It generates the file Parks_vs_Urban_Areas_Biodiversity_Native.csv, which will be used later in Models.R and Plotting.R .

4) Condition_Models.R : this file reads in the raw datasheets and performs models to determine whether tree condition (health) is correlated with diameter at breast height, nativity status (introduced vs. naturally occurring), and location (in a park vs. urban space). It generates the file Condition_Models_Results.csv.
		
5) Models.R : this file performs a PCA of the environmental data, constructs linear models to determine what influences effective species counts across cities, calculates the correlation coefficient for maximum abundance vs. effective species count (two different measures of biodiversity), constructs beta regression moedls to determine what influences the abundance of native species across cities, calculates the correlation coefficient between a city's overall biodiversity and the biodiversity of its native trees, analyzes the drivers of across-species similarity in tree communities (native-only and whole-community), and compares biodiversity and abundance of native trees between parks and urban areas.	
	
		
6) Clustering_Calculate_Scores.ipynb : This file implements hdbscan, hierarchical density-based clustering algorithms, to assign all trees in each city to clusters. HDBscan takes into account the underlying structure of the data. This files produces 49 new datasheets (one per city, excluding cities without location information) with the trees assigned to clusters; these datasheets are located in a folder entitled Clustered CSVs and will be used in the file Clustering_Analysis.R		
		
7) Clustering_Analysis.R : this file reads in datasheets from the folder entitled Clustered CSVs and performs a statistical analysis to determine whether trees are randomly arranged or nonrandomly clustered by species. It saves statistics for each cluster within each city in city-specific datasheets in a folder entitled Cluster Stats Sheets. It further produces a summary datasheet with information on all cities entitled clustering_results_final.csv, which will be used in the code file Plotting.R . 		
		
8) Plotting.R : this file generates all the figures in the manuscript and supplement.		
