## This file reads in raw spreadsheets that have latitude and longitude coordinates
## and calculates metrics of how evenly sampled the city is. 
## to do so, cities are divide dinto grids and the percentage of empty grid cells
## is calcualted, as well as the skew and kurtosis of the distribution of 
## number of trees per cell (excluding empty cells)


library(dplyr)
library(ggplot2)
library(tigris)
library(sf)
library(rgeos)
library(rgdal)
library(raster)
library(moments)
library(beepr)
options(tigris_use_cache = TRUE)

beep()

## bug fix for erasing water from our city maps
sf_use_s2(FALSE)


dir_rawsheets <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis/Final Spreadsheets'
home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis'

setwd(home_dir)
city_info<-read.csv("city_information.csv")



## read in raw spreadsheets
setwd(dir_rawsheets)
all_files<-list.files(pattern = ".csv$")


LIST_COVERAGE<-list()

######################################################################
##
## Divide each city into a grid and assign trees to grid cells.
##
######################################################################
for (i in 1:length(all_files)) {
  
  ## read data
  data<-read.csv(all_files[i])

  # get lon lat coordinates for each tree
  points<-data%>%
    select(longitude_coordinate,latitude_coordinate)%>%
    filter(!is.na(latitude_coordinate))%>%
    filter(!is.na(longitude_coordinate))
  
  ## make sure there are lat and lon coordinates for the data before proceeding

  if (nrow(points)>1){
    
    ######################################################################
    ##
    ## first, get spatial boundaries of your city and divide it into a grid
    ##
    ######################################################################
    
    # save city and state names
    mystate=data$state[1]
    mycity_raw=strsplit(all_files[i],"_")[[1]][1]
    mycity<-(city_info%>%filter(filename_city==mycity_raw))$city_tigris
    
    # select that state
    pl <- places(state = mystate, year = 2018, cb = TRUE)
    
    # select that city
    this_city <- filter(pl, NAME == mycity)
    
    # check that we got the city name right
    if(length(this_city$NAME)>0){
     
      # this_city
      # plot(this_city)
      
      ## get rid of water features
      ## note that we ran into a bug which was not deleting water from certain areas, 
      ## but that bug was fixed by running sf_use_s2(FALSE) before everything else.
      tryCatch({
        this_city<-erase_water(this_city)
      }, error=function(e){print(paste("no water in",all_files[i]))})
      
      # 
      ## check to see the plot with removed water
      # plot(whole_city[1])
      
      # make a grid from this polygon
      # see notes at: https://rpubs.com/huanfaChen/grid_from_polygon
      dat<-this_city[1]
      
      mycity_spatial<-as_Spatial(dat)
      
      # note the order of resolution
      grid <- raster(extent(mycity_spatial), resolution = c(0.005,0.005))
      
      grid <- raster::extend(grid, c(1,1))
      
      
      # convert to SpatialPolygonsDataFrame
      gridPolygon <- rasterToPolygons(grid)
  
      # get the intersection
      gridPolygon$id <- 1:nrow(gridPolygon)
      intersectGrid <- raster::intersect(gridPolygon, mycity_spatial)
      
      # give coordinate reference system to the grid
      crs(intersectGrid)<-crs(this_city) 
      
      ######################################################################
      ##
      ## second, you need to count tree points per grid cell
      ##
      ######################################################################
      
      # save coordinate reference system to apply to points
      my_CRS<-crs(intersectGrid)
      
      
      ### Get long and lat from your data.frame. Make sure that the order is in lon/lat.
      ### convert to spatial polygons data frame
      points<-na.omit(points)
      xy <- points[,c(1,2)]
      
      spdf <- SpatialPointsDataFrame(coords = xy, data = points,
                                     proj4string = CRS("+proj=longlat +datum=NAD83"))
      
      ######################################################################
      ##
      ## Third, plot the trees on the city divided into  a grid
      ##
      ######################################################################
      png(file= paste0('C:/Users/dakot/Dropbox/PC/Documents/Trees/Figures/CoveragePlots/',
                 strsplit(all_files[i],"_")[[1]][1],".png",sep=""),
          width=1000, height=1000)
      plot(intersectGrid)
      plot(spdf,pch=20,cex=.1,col="blue",add=T)
      dev.off()
      
      ######################################################################
      ##
      ## Fourth, get adjusted number of points per grid cell (controlling for area)
      ## this both controls for the fact that area changes by lat and lon
      ## and also that some of the grid cells are truncated (at the edge of the city)
      ##
      ######################################################################
      
      ### find area of each grid cell
      area<-area(intersectGrid)
      id<-intersectGrid$id
      
      ### convert to be a fraction of the maximum grid cell size
      ### set normal grid cell size equal to 1
      area_gridcells<-data.frame(area,id)%>%
        mutate(area=area/max(area))
      
      ## now, assign each point to a grid cell
      points_in_gridcells<- over(spdf, intersectGrid)
      
      points_in_gridcells<-as.data.frame(points_in_gridcells)
      
      count_table<-points_in_gridcells%>%
        count(id)
      
      
      ## merge counts with grid cell area to get a final dataframe
      
      full_data<-merge(count_table,area_gridcells,by="id",all=T)%>%
        mutate(n_adj=n/area)
      
      # replace NA values with 0 since that means there were zero trees in that grid cell.
      full_data[is.na(full_data)] <- 0
      
      # add filename
      full_data$filename_city<-mycity_raw
      
      # save file
      LIST_COVERAGE[[i]]<-full_data
    } else {
      print(paste("wrong city name for",all_files[i]))
    }
  }
}


beep()
length(LIST_COVERAGE)
LIST_COVERAGE[[1]]


all_dat<-do.call("rbind",c(LIST_COVERAGE, make.row.names = FALSE))

all_dat<-all_dat%>%
  rename("gridcell_ID"="id",
         "n_trees"="n",
        "area_gridcell"="area",
        "n_trees_adj"="n_adj")

write.csv(all_dat,"SpatialCoverage_Raw_Data.csv",row.names = FALSE)


### figure out how many grid cells are empty
summarized<-all_dat%>%
  group_by(filename_city)%>%
  summarize(empty_cells=sum(n_trees_adj==0),
            total_cells=n())%>%
  mutate(percent_cells_empty=empty_cells/total_cells)


#calculate skewness and kurtosis of the data (filtering out empty cells)
#
skew_kurtosis<-all_dat%>%
  filter(n_trees_adj>0)%>%
  group_by(filename_city) %>%
  summarise(skew_occupied_cells = skewness(n_trees_adj), 
            kurtosis_occupied_cells = kurtosis(n_trees_adj))


final<-merge(summarized,skew_kurtosis)

setwd(home_dir)
write.csv(final,"SpatialCoverage_Summary_Data.csv",row.names=FALSE)