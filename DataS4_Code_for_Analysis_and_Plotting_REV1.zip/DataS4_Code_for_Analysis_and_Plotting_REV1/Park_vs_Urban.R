# this file reads in the raw datasheets, 63 city files 
# where every row is a tree, and compares the biodiversity
# (and abundance of native trees) in parks to that of urban areas.



# packages
library("dplyr")
library("ggplot2")
library("stringr")
library("beepr")
library("tidyr")
library("iNEXT")


# set up our directories
home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis'
dir_rawsheets <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis/Final Spreadsheets'

setwd(dir_rawsheets)

# ## make a blank list to fill it in with dataframes
# list<-list()

all_files<-list.files(pattern = ".csv$")

##############################################
##
## Metrics within Parks vs Urban Settings
##
##############################################

## make a blank matrix to fill in results
column_names<-c(# details
                      "filename_city",
                      "number_all_trees_park",
                      "number_all_trees_urban",
                      "number_counted_trees_park",
                      "number_counted_trees_urban",
                      "population_size_standardized",
                      # max abundance and most common
                      "max_abundance_most_common_species_park",
                      "max_abundance_most_common_species_urban",
                      "most_common_species_park",
                      "most_common_species_urban",
                      # percent native
                      "percent_native_park",
                      "percent_native_urban",
                      # diversity
                      ### park variables
                      "number_species_park",
                      "number_species_asymest_park",
                      "number_species_asymest_SE_park",
                      "number_species_asymest_CIlower_park",
                      "number_species_asymest_CIhigher_park",
                      "effective_species_park",
                      "effective_species_asymest_park",
                      "effective_species_asymest_SE_park",
                      "effective_species_asymest_CIlower_park",
                      "effective_species_asymest_CIhigher_park",
                      "number_species_givenpop_park",
                      "number_species_givenpop_method_park",
                      "number_species_givenpop_CIlower_park",
                      "number_species_givenpop_CIhigher_park",
                      "effective_species_givenpop_park",
                      "effective_species_givenpop_method_park",
                      "effective_species_givenpop_CIlower_park",
                      "effective_species_givenpop_CIhigher_park",
                      "samplecoverage_estimate_park",
                      ### urban variables
                      "number_species_urban",
                      "number_species_asymest_urban",
                      "number_species_asymest_SE_urban",
                      "number_species_asymest_CIlower_urban",
                      "number_species_asymest_CIhigher_urban",
                      "effective_species_urban",
                      "effective_species_asymest_urban",
                      "effective_species_asymest_SE_urban",
                      "effective_species_asymest_CIlower_urban",
                      "effective_species_asymest_CIhigher_urban",
                      "number_species_givenpop_urban",
                      "number_species_givenpop_method_urban",
                      "number_species_givenpop_CIlower_urban",
                      "number_species_givenpop_CIhigher_urban",
                      "effective_species_givenpop_urban",
                      "effective_species_givenpop_method_urban",
                      "effective_species_givenpop_CIlower_urban",
                      "effective_species_givenpop_CIhigher_urban",
                      "samplecoverage_estimate_urban")

my_output<-matrix(nrow=length(all_files),ncol=length(column_names))
colnames(my_output)<-column_names

for (i in 1:length(all_files)){
  
  ##########################################################################
  ## read in data
  ##########################################################################
  data<-read.csv(all_files[i])
  
  ##########################################################################
  ## filename
  ##########################################################################
  my_output[i,"filename_city"]<-strsplit(all_files[i], '_')[[1]][1]
  
  elements_urban<-nrow(data%>%filter(location_type=="built_environment"))
  elements_park<-nrow(data%>%filter(location_type=="green_space"))
  
  ##########################################################################
  ## make a bunch of calculations IF the dataframe has data on location type.
  ##########################################################################
  if (elements_urban>50){
    if(elements_park>50){
      
      summary<-data%>%
        dplyr::select(scientific_name,state,city,native,location_type)%>%
        filter(scientific_name!="")%>%
        group_by(scientific_name,native,location_type)%>%
        summarise(n=n())
      
      ## count words in species name
      summary$word_count<-str_count(summary$scientific_name, '\\w+')
      
      ## make list of genera
      genusonlylist<-summary%>%filter(word_count==1)
      speciesonlylist<-summary%>%filter(word_count==2)
      genusonlylist$unique_genus="NA"
      genusonlylist
      
      for (j in 1:nrow(genusonlylist)){
        ## select each genus-only scientific name
        genus=genusonlylist$scientific_name[j]
        ## generate regex search term
        genus_at_start=paste0("^",genus," ",sep="")
        ## count other instances in full dataset of species who share that genus 
        count_genus<-sum(str_count(summary$scientific_name, pattern = genus_at_start))
        ## label with unique or duplicate
        ifelse(count_genus==0,genusonlylist$unique_genus[j]<-"unique",genusonlylist$unique_genus[j]<-"duplicate")
      }
      speciesonlylist<-speciesonlylist%>%
        mutate(unique_genus="species")
      
      ## bind the "unique" rows back to the dataset
      alldata_subset<-rbind(speciesonlylist,genusonlylist)%>%
        dplyr::select(-word_count)

      
      ##########################################################################
      ## extract park and urban data frames
      ##########################################################################
      data_parks<-alldata_subset%>%
        filter(location_type=="green_space")
      
      biodiv_data_parks<-data_parks%>%
        filter(unique_genus!="duplicate")
      
      data_urban<-alldata_subset%>%
        filter(location_type=="built_environment")
      
      biodiv_data_urban<-data_urban%>%
        filter(unique_genus!="duplicate")
      
      ##########################################################################
      ## max abundance and most common species
      ##########################################################################
      
      ###############
      ### Parks
      ###############
      
      if (nrow(biodiv_data_parks)>0){
        # most common species
        my_output[i,"most_common_species_park"]<-biodiv_data_parks$scientific_name[which.max(biodiv_data_parks$n)]
        my_output[i,"max_abundance_most_common_species_park"]<-biodiv_data_parks$n[which.max(biodiv_data_parks$n)]/
                                                                                    sum(biodiv_data_parks$n)
      }
      ###############
      ### Urban
      ###############
      
      if (nrow(biodiv_data_urban)>0){
        # most common species
        my_output[i,"most_common_species_urban"]<-biodiv_data_urban$scientific_name[which.max(biodiv_data_urban$n)]
        my_output[i,"max_abundance_most_common_species_urban"]<-biodiv_data_urban$n[which.max(biodiv_data_urban$n)]/
                                                                                     sum(biodiv_data_urban$n)
      }
      
      
      ##########################################################################
      ## sample sizes
      ##########################################################################
      
      my_output[i,"number_all_trees_park"]<-sum(data_parks$n)
      my_output[i,"number_counted_trees_park"]<-sum(biodiv_data_parks$n)
      my_output[i,"number_all_trees_urban"]<-sum(data_urban$n)
      my_output[i,"number_counted_trees_urban"]<-sum(biodiv_data_urban$n)
      
      ##########################################################################
      ## native species
      ##########################################################################
      
      #######
      # PARKS
      #######
      status_known_data_parks<-alldata_subset%>%
        filter(location_type=="green_space")%>%
        filter(native!="no_info")
      native_data_all_parks<-alldata_subset%>%
        filter(location_type=="green_space")%>%
        filter(native=="naturally_occurring")
      
      #######
      # URBAN
      #######
      status_known_data_urban<-alldata_subset%>%
        filter(location_type=="built_environment")%>%
        filter(native!="no_info")
      native_data_all_urban<-alldata_subset%>%
        filter(location_type=="built_environment")%>%
        filter(native=="naturally_occurring")
      
      ## save data
      my_output[i,"percent_native_park"]<-sum(native_data_all_parks$n)/
        sum(status_known_data_parks$n)
      my_output[i,"percent_native_urban"]<-sum(native_data_all_urban$n)/
        sum(status_known_data_urban$n)
      
      
      ##########################################################################
      ## Diversity values and estimates using iNEXT
      ##########################################################################
      
      ## find the smaller of the two population sizes in order to make comparable estimates of diversity
      pop_size<-min(sum(biodiv_data_parks$n), sum(biodiv_data_urban$n))
      
      my_output[i,"population_size_standardized"]<-pop_size
      
      location_categories<-c("park","urban")
      
      for (value in location_categories) {
        ifelse (value =="park",
                abun<-as.numeric(biodiv_data_parks$n),
                ## native trees only
                ifelse(value=="urban",
                       abun<-as.numeric(biodiv_data_urban$n),
                       print("something went wrong")))
        # q=c(0,1) refers to selecting order 0 (species richness) 
        ## and order 1 (shannon diversity = effective species)
      # make diversity estimates for park and urban

        
        x<-iNEXT(abun, q=c(0,1), datatype="abundance",nboot=50,
                 # get estimates up to the defined population size we will use for standard comparisons
                 size=c(sum(abun),pop_size))
        
      # species richness
        my_output[i,paste0("number_species_",value,sep="")]<-x$AsyEst["Species Richness","Observed"]
        my_output[i,paste0("number_species_asymest_",value,sep="")]<-x$AsyEst["Species Richness","Estimator"]
        my_output[i,paste0("number_species_asymest_SE_",value,sep="")]<-x$AsyEst["Species Richness","Est_s.e."]
        my_output[i,paste0("number_species_asymest_CIlower_",value,sep="")]<-x$AsyEst["Species Richness","95% Lower"]
        my_output[i,paste0("number_species_asymest_CIhigher_",value,sep="")]<-x$AsyEst["Species Richness","95% Upper"]
      
      # shannon diversity = effective species number
        my_output[i,paste0("effective_species_",value,sep="")]<-x$AsyEst["Shannon diversity","Observed"]
        my_output[i,paste0("effective_species_asymest_",value,sep="")]<-x$AsyEst["Shannon diversity","Estimator"]
        my_output[i,paste0("effective_species_asymest_SE_",value,sep="")]<-x$AsyEst["Shannon diversity","Est_s.e."]
        my_output[i,paste0("effective_species_asymest_CIlower_",value,sep="")]<-x$AsyEst["Shannon diversity","95% Lower"]
        my_output[i,paste0("effective_species_asymest_CIhigher_",value,sep="")]<-x$AsyEst["Shannon diversity","95% Upper"]
      
      # save sample coverage estimate
      
        my_output[i,paste0("samplecoverage_estimate_",value,sep="")]<-x$DataInfo[["SC"]]
      
      
        ### estimate the diversity values given a population size that represents
        ### the smaller population (park vs urban)
        y<- x$iNextEst%>%
          filter(m==pop_size)%>% #filter m>1 to get rid of the estimates for pop size 1 tree.
          distinct() # filter to get rid of duplicate rows
        # label the rows by which diversity index they represent
        rownames(y)<-paste("order",y$order,sep="")
      

        # extract estimates, where "order 0" represents species richness
        my_output[i,paste0("number_species_givenpop_",value,sep="")]<-y["order0","qD"]
        my_output[i,paste0("number_species_givenpop_method_",value,sep="")]<-y["order0","method"]
        my_output[i,paste0("number_species_givenpop_CIlower_",value,sep="")]<-y["order0","qD.LCL"]
        my_output[i,paste0("number_species_givenpop_CIhigher_",value,sep="")]<-y["order0","qD.UCL"]
        
        # extract estimates, where "order 1" represents shannon weiner diversity = effective species number
        my_output[i,paste0("effective_species_givenpop_",value,sep="")]<-y["order1","qD"]
        my_output[i,paste0("effective_species_givenpop_method_",value,sep="")]<-y["order1","method"]
        my_output[i,paste0("effective_species_givenpop_CIlower_",value,sep="")]<-y["order1","qD.LCL"]
        my_output[i,paste0("effective_species_givenpop_CIhigher_",value,sep="")]<-y["order1","qD.UCL"]
      }
    }
  } 
}





beep()
my_output

# remove cities that didn't have data
al_output<-as.data.frame(my_output)%>%
  filter(!(is.na(filename_city)))%>%
  filter(number_counted_trees_park>0)%>%
  filter(number_counted_trees_urban>0)

# make the numeric columns numeric
numeric_columns<-column_names[! column_names %in% c("filename_city",
                                                    "most_common_species_park",             
                                                    "most_common_species_urban",
                                                    "effective_species_givenpop_method_urban",
                                                    "effective_species_givenpop_method_park",
                                                    "number_species_givenpop_method_urban",
                                                    "number_species_givenpop_method_park")]

al_output[,numeric_columns]<-sapply(al_output[,numeric_columns],as.numeric)
al_output
beep()
write.csv(al_output,paste0(home_dir,"/Parks_vs_Urban_Areas_Biodiversity_Native.csv"),row.names = FALSE)

