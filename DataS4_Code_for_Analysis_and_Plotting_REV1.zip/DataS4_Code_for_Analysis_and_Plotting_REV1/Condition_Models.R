###
### does location_type correlate with condition?
###

# packages
library("dplyr")
library("ggplot2")
library("stringr")
library("beepr")
library("arm")
library("glm2")

# set up our directories
home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis'
dir_rawsheets <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis/Final Spreadsheets'

setwd(dir_rawsheets)

# ## make a blank list to fill it in with dataframes
# list<-list()

all_files<-list.files(pattern = ".csv$")


results<-matrix(nrow=length(all_files),ncol=15)
colnames(results)<-c("city",
                     "native_OR", "native_pval","native_CI_left","native_CI_right",
                     "location_type_OR", "location_type_pval","location_type_CI_left","location_type_CI_right",
                     "DBH_OR", "DBH_pval","DBH_CI_left","DBH_CI_right",
                    "model_pval","N_trees") 


#### good work here

## change the check unique parts to be "in"

for (i in 1:length(all_files)) {
  # read in file and select relevant columns
  data<-read.csv(all_files[i])%>%
    dplyr::select(condition,native,location_type,scientific_name,
                  diameter_breast_height_CM)
  mycity<-strsplit(all_files[i],"_")[[1]][1]

    # limit to files that have condition coded for >1000 trees
  if (sum(!is.na(data$condition)) > 1000) {
    # and recode condition to be binary
   data_recoded<-data %>%
      mutate(condition_numeric=ifelse(condition=="excellent",1,
                                      ifelse(condition=="good",1,
                                             ifelse(condition=="fair",1,
                                                    ifelse(condition=="poor",0,
                                                           ifelse(condition=="dead",0,
                                                                  ifelse(condition=="dead/dying",0,"NA")
                                                           ))))))%>%
     filter(!(is.na(condition_numeric)))
   data_recoded$condition_numeric<-as.numeric(data_recoded$condition_numeric)
   
   ## some files don't have enough trees coded in each of the two location types.
   ## number of green
   num_park<-sum(data_recoded$location_type=="green_space",na.rm=TRUE)
   ## number of built
   num_urban<-sum(data_recoded$location_type=="built_environment",na.rm=TRUE)
   ## if that's the case, just delete the column
   if(num_park<250 | num_urban<250){
     data_recoded$location_type<-NA
   }
   
   ## some files don't have enough DBH records
   num_DBH<-sum(data_recoded$diameter_breast_height_CM>0,
                 na.rm=TRUE)
   ## if that's the case, just delete the column
   if(num_DBH<500){
     data_recoded$diameter_breast_height_CM<-NA
   }
   
   ## some files don't have enough trees coded in each of the two condition types
   ## number of condition 1
   num_one<-sum(data_recoded$condition_numeric==1,na.rm=TRUE)
   ## number of condition 0
   num_zero<-sum(data_recoded$condition_numeric==0,na.rm=TRUE)
   
  ## make sure there are at least 250 of each before proceeding!
   if(num_one>250 & num_zero>250){
     
  
     ################################################################################# 
     ###############################################################################
     #
     # files that have NATIVE status, LOCATION_TYPE, and DIAMETER_BREAST_HEIGHT_CM
     #
     #################################################################################
     #################################################################################
     
      if(sum(!is.na(data_recoded$native)) > 0 &
         sum(!is.na(data_recoded$location_type)) > 0 &
         sum(!is.na(data_recoded$diameter_breast_height_CM )) > 0) {
        
        ## filter data
        model_data<-data_recoded%>%
          filter(native!="no_info")%>%
          filter(location_type!="no_info")%>%
          filter(!(is.na(native)))%>%
          filter(!(is.na(location_type)))%>%
          filter(location_type %in% c("green_space","built_environment"))%>%
          filter(!(is.na(diameter_breast_height_CM)))%>%
          filter(diameter_breast_height_CM>0)
        
        # get correct data types
        model_data$native<-as.factor(model_data$native)
        model_data$location_type<-as.factor(model_data$location_type)
        model_data$diameter_breast_height_CM<-as.numeric(model_data$diameter_breast_height_CM)
        
        # if you have more than one level for each variable of interest
        # and more than 1000 trees represented
        if (nrow(model_data)>2000 &
            length(unique(model_data$condition_numeric))>1&
            length(unique(model_data$native))>1&
            length(unique(model_data$location_type))>1&
            length(unique(model_data$diameter_breast_height_CM))>1){
          # then run the model
          mylogit <- glm2(condition_numeric~ 
                            native + 
                            diameter_breast_height_CM +
                            location_type,
                          data = model_data, family = binomial(link = "logit"),
                          maxit=25)
          
          ## save results
          #coefficients
          results[i, "native_OR"]<- exp(coef(mylogit)[['nativenaturally_occurring']])
          results[i, "native_CI_left"]<- exp( confint.default(mylogit)["nativenaturally_occurring",1])
          results[i, "native_CI_right"]<- exp( confint.default(mylogit)["nativenaturally_occurring",2])
          results[i, "location_type_OR"]<- exp(coef(mylogit)[['location_typegreen_space']])
          results[i, "location_type_CI_left"]<- exp( confint.default(mylogit)["location_typegreen_space",1])
          results[i, "location_type_CI_right"]<- exp( confint.default(mylogit)["location_typegreen_space",2])
          results[i, "DBH_OR"]<- exp(coef(mylogit)[['diameter_breast_height_CM']])
          results[i, "DBH_CI_left"]<- exp( confint.default(mylogit)["diameter_breast_height_CM",1])
          results[i, "DBH_CI_right"]<- exp( confint.default(mylogit)["diameter_breast_height_CM",2])
          #p values
          results[i, "native_pval"]<-coef(summary(mylogit))[,4][['nativenaturally_occurring']]
          results[i, "location_type_pval"]<-coef(summary(mylogit))[,4][['location_typegreen_space']]
          results[i, "DBH_pval"]<-coef(summary(mylogit))[,4][['diameter_breast_height_CM']]
          ## does model fit significantly better than an empty model?
          results[i, "model_pval"]<-with(mylogit, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))
          results[i,"N_trees"]<-nrow(model_data)
          }
      }
        
      
      ################################################################################# 
      ###############################################################################
      #
      # files that have NATIVE status and LOCATION_TYPE
      # but no DIAMETER_BREAST_HEIGHT_CM
      #
      #################################################################################
      #################################################################################
      if(sum(!is.na(data_recoded$native)) > 0 &
         sum(!is.na(data_recoded$location_type)) > 0 &
         sum(!is.na(data_recoded$diameter_breast_height_CM )) == 0) {
        
        ## filter data
        model_data<-data_recoded%>%
          filter(native!="no_info")%>%
          filter(location_type!="no_info")%>%
          filter(!(is.na(native)))%>%
          filter(!(is.na(location_type)))
        
        # get correct data types
        model_data$native<-as.factor(model_data$native)
        model_data$location_type<-as.factor(model_data$location_type)
  
        # if you have more than one level for each variable of interest
        # and more than 1000 trees represented
        if (nrow(model_data)>2000 &
            length(unique(model_data$condition_numeric))>1&
            length(unique(model_data$native))>1&
            length(unique(model_data$location_type))>1){
          # then run the model
          mylogit <- glm2(condition_numeric~ 
                            native + 
                            location_type,
                          data = model_data, family = binomial(link = "logit"),
                          maxit=25)
          
          ## save results
          #coefficients
          results[i, "native_OR"]<- exp(coef(mylogit)[['nativenaturally_occurring']])
          results[i, "native_CI_left"]<- exp( confint.default(mylogit)["nativenaturally_occurring",1])
          results[i, "native_CI_right"]<- exp( confint.default(mylogit)["nativenaturally_occurring",2])
          results[i, "location_type_OR"]<- exp(coef(mylogit)[['location_typegreen_space']])
          results[i, "location_type_CI_left"]<- exp( confint.default(mylogit)["location_typegreen_space",1])
          results[i, "location_type_CI_right"]<- exp( confint.default(mylogit)["location_typegreen_space",2])
          #p values
          results[i, "native_pval"]<-coef(summary(mylogit))[,4][['nativenaturally_occurring']]
          results[i, "location_type_pval"]<-coef(summary(mylogit))[,4][['location_typegreen_space']]
          ## does model fit significantly better than an empty model?
          results[i, "model_pval"]<-with(mylogit, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))
          results[i,"N_trees"]<-nrow(model_data)
          }
      }
          
     ################################################################################# 
     ###############################################################################
     #
     # files that have NATIVE status and DIAMETER_BREAST_HEIGHT
     # but no LOCATION_TYPE
     #
     #################################################################################
     #################################################################################
     if(sum(!is.na(data_recoded$native)) > 0 &
        sum(!is.na(data_recoded$location_type)) == 0 &
        sum(!is.na(data_recoded$diameter_breast_height_CM )) > 0) {
       
       ## filter data
       model_data<-data_recoded%>%
         filter(native!="no_info")%>%
         filter(!(is.na(native)))%>%
         filter(!(is.na(diameter_breast_height_CM)))%>%
         filter(diameter_breast_height_CM>0)
       
       # get correct data types
       model_data$native<-as.factor(model_data$native)
       model_data$diameter_breast_height_CM<-as.numeric(model_data$diameter_breast_height_CM)
       
       # if you have more than one level for each variable of interest
       # and more than 1000 trees represented
       if (nrow(model_data)>2000 &
           length(unique(model_data$condition_numeric))>1&
           length(unique(model_data$native))>1&
           length(unique(model_data$diameter_breast_height_CM))>1){
         # then run the model
         mylogit <- glm2(condition_numeric~ 
                           native + 
                           diameter_breast_height_CM,
                         data = model_data, family = binomial(link = "logit"),
                         maxit=25)
         
         ## save results
         #coefficients
         results[i, "native_OR"]<- exp(coef(mylogit)[['nativenaturally_occurring']])
         results[i, "native_CI_left"]<- exp( confint.default(mylogit)["nativenaturally_occurring",1])
         results[i, "native_CI_right"]<- exp( confint.default(mylogit)["nativenaturally_occurring",2])
         results[i, "DBH_OR"]<- exp(coef(mylogit)[['diameter_breast_height_CM']])
         results[i, "DBH_CI_left"]<- exp( confint.default(mylogit)["diameter_breast_height_CM",1])
         results[i, "DBH_CI_right"]<- exp( confint.default(mylogit)["diameter_breast_height_CM",2])
         #p values
         results[i, "native_pval"]<-coef(summary(mylogit))[,4][['nativenaturally_occurring']]
         results[i, "DBH_pval"]<-coef(summary(mylogit))[,4][['diameter_breast_height_CM']]
         ## does model fit significantly better than an empty model?
         results[i, "model_pval"]<-with(mylogit, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))
         results[i,"N_trees"]<-nrow(model_data)
         }
     }
   }
  }
  results[i,"city"]<-mycity
}




beep()

results_clean<-as.data.frame(results)

results_clean[,2:14]<-sapply(results_clean[,2:14],as.numeric)

results_clean<-results_clean%>%
  filter(!(is.na(model_pval)))%>%
  arrange(location_type_OR)%>%
  arrange(location_type_OR)%>%
  mutate(DBH_pstars=ifelse(DBH_pval<0.0005,"***",
                       ifelse(DBH_pval<0.005,"**",
                          ifelse(DBH_pval<0.05,"*",
                             "(NS)"))))%>%
  mutate(native_pstars=ifelse(native_pval<0.0005,"***",
                           ifelse(native_pval<0.005,"**",
                                  ifelse(native_pval<0.05,"*",
                                         "(NS)"))))%>%
  mutate(location_type_pstars=ifelse(location_type_pval<0.0005,"***",
                           ifelse(location_type_pval<0.005,"**",
                                  ifelse(location_type_pval<0.05,"*",
                                         "(NS)"))))%>%
  mutate(model_pstars=ifelse(model_pval<0.0005,"***",
                                     ifelse(model_pval<0.005,"**",
                                            ifelse(model_pval<0.05,"*",
                                                   "(NS)"))))%>%
  mutate(native_OR=round(native_OR,2))%>%
  mutate(location_type_OR=round(location_type_OR,2))%>%
  mutate(DBH_OR=round(DBH_OR,4))
  
results_clean$native<-paste(results_clean$native_OR,
                            results_clean$native_pstars,
                            sep="")



results_clean$location_type<-paste(results_clean$location_type_OR,
                            results_clean$location_type_pstars,
                            sep="")

results_clean$DBH<-paste(results_clean$DBH_OR,
                            results_clean$DBH_pstars,
                            sep="")

results_clean$native_CI<-paste("[",
                               round(results_clean$native_CI_left,2), 
                               ", ", 
                               round(results_clean$native_CI_right,2),
                               "]",sep="")

results_clean$DBH_CI<-paste("[",
                               round(results_clean$DBH_CI_left,4), 
                               ", ", 
                               round(results_clean$DBH_CI_right,4),
                               "]",sep="")

results_clean$location_type_CI<-paste("[",
                               round(results_clean$location_type_CI_left,2), 
                               ", ", 
                               round(results_clean$location_type_CI_right,2),
                               "]",sep="")

results_clean%>%
  dplyr::select(DBH_OR,DBH_CI,DBH_pstars)%>%
  arrange(DBH_OR)

results_clean%>%
  dplyr::select(native_OR,native_CI,native_pstars)%>%
  arrange(native_OR)

results_clean%>%
  dplyr::select(location_type_OR,location_type_CI,location_type_pstars)%>%
  arrange(location_type_OR)

results_clean$N_trees<-as.numeric(results_clean$N_trees)
results_clean$N_trees<-format(results_clean$N_trees, big.mark=",")
results_save<-results_clean%>%
  dplyr::select(city,
                location_type,location_type_CI,
                DBH, DBH_CI,
                native,native_CI,
                model_pstars,N_trees)%>%
  group_by(location_type,DBH,native)%>%
  arrange(location_type,native)


results_save
#####################
## below here is old and bad.
#######################
setwd(home_dir)
write.csv(results_save,"Condition_Models_Results.csv")


