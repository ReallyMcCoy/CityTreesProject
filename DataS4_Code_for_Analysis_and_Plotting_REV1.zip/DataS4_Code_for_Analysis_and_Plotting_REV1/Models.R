# this file performs a PCA of the environmental data, constructs linear
# models to determine what influences effective species counts across 
# cities, calculates the correlation coefficient for maximum abundance
# vs. effective species count (two different measures of biodiversity),
# constructs beta regression models to determine what influences the 
# abundance of native species across cities, calculates the correlation 
# coefficient between a city's overall biodiversity and the biodiversity
# of its native trees, analyzes the drivers of across-species similarity
# in tree communities (native-only and whole-community), and compares 
# biodiversity and abundance of native trees between parks and urban areas.


# packages
library("dplyr")
library("ggplot2")
library("stringr")
library("betareg")
library("lmtest")
library("geosphere")
library("tidyr")
library("cocor")
library("olsrr")



# set up our directories
home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis'
setwd(home_dir)
data<-read.csv("City_Data_Diversity_Enviroment_Social_Coverage.csv")
park_vs_urban<-read.csv("Parks_vs_Urban_Areas_Biodiversity_Native.csv")
similarity_all<-read.csv("Species_Composition_Comparisons_ALL.csv")%>%
  separate(file_city1,into="city1",sep="_",remove = FALSE)%>%
  separate(file_city2,into="city2",sep="_",remove = FALSE)%>%
  # drop filenames
  select(-file_city1,-file_city2)
similarity_native<-read.csv("Species_Composition_Comparisons_NATIVE.csv")%>%
  separate(file_city1,into="city1",sep="_",remove = FALSE)%>%
  separate(file_city2,into="city2",sep="_",remove = FALSE)%>%
  # drop filenames
  select(-file_city1,-file_city2)
similarity_nonnative<-read.csv("Species_Composition_Comparisons_NONNATIVE.csv")%>%
  separate(file_city1,into="city1",sep="_",remove = FALSE)%>%
  separate(file_city2,into="city2",sep="_",remove = FALSE)%>%
  # drop filenames
  select(-file_city1,-file_city2)


####################################################################
####################################################################
####################################################################
###
###  PCA of environmental data
###
####################################################################
####################################################################
####################################################################
## subset only the environmental columns from our data frame
env_data<-data[c(which(colnames(data)=="Precip_Coldest_Quarter"):which(colnames(data)=="Annual_Mean_Temp"))]

## label the rows by city
rownames(env_data)<-data$filename_city

## conduct PCA
pca<-princomp(env_data, cor = TRUE, scores = TRUE)

## check and save the scores
pca$scores
pca_scores=as.data.frame(pca$scores)
pca_scores$filename_city<-rownames(pca_scores)
write.csv(pca_scores,"Environmental_PCA_Scores.csv")

## check and save loadings for the first four
pca$loadings[,1:ncol(pca$loadings)]
write.csv(as.data.frame(pca$loadings[,1:ncol(pca$loadings)])%>%
            arrange(-abs(Comp.1)), "Environmental_PCA_Loadings.csv")

## check and save proportion of variance explained by first 4
proportions_variance<-(pca$sdev^2/sum(pca$sdev^2))
write.csv(proportions_variance,"Environmental_PCA_ProportionVariance.csv")

# #### code for later
# round(proportions_variance[[1]]*100,1)
# Variance_Explained_First_Four<-sum(proportions_variance[1:4])

## merge PCA with whole dataframe for modelling
all_data<-merge(pca_scores,data)

head(all_data)

####################################################################
####################################################################
####################################################################
###
###  Effective Species Count Across Cities
###
####################################################################
####################################################################
####################################################################

####################################################################
###
###  First, construct model with all predictors and identify / remove outliers
###  to do so, we use the effective species number calculated by iNext at a standardized
###  population size 
###
####################################################################

model1<-lm(effective_species_givenpop_all ~
             Comp.1*Comp.2+
             city_age_2021* tree_city_USA,
           data=all_data)
summary(model1)

# identify outliers 
ols_plot_cooksd_bar(model1)

# no major outliers; therefore, continue

####################################################################
###
###  Identify the best model by comparing models with different variables
###
####################################################################

k<-ols_step_all_possible(model1)
plot(k)

# let's find the lowest AIC based on all possible predictors

## best models

## "Comp.1 tree_city_USA"
k[8,]$aic
k[8,]$predictors

## "Comp.1 tree_city_USA Comp.1:Comp.2"
k[22,]$aic
k[22,]$predictors

## because these models perform so similarly, we will include these three predictor terms
# "Comp.1 tree_city_USA Comp.1:Comp.2"

####################################################################
###
###  run best model under a variety of different sensitivity tests
###
####################################################################

###  cities included: all
### independent variable: effective_species_givenpop_all 
###### that is, the rarefied or extrapolated effective species count
###### for a tree population = median of 37,000 trees

model_op1<-lm(effective_species_givenpop_all~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data)

summary(model_op1)

ols_plot_cooksd_bar(model_op1)
# no egregious outliers


###  cities included: all
### independent variable: effective_species_asymest_all 
###### that is, the asymptotic estimate for effective species count 
###### from the package iNEXT

model_op2<-lm(effective_species_asymest_all~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data)

summary(model_op2)

ols_plot_cooksd_bar(model_op2)
# no egregious outliers


###  cities included: all
### independent variable: effective_species 
###### that is, the actual observed effective species number

model_op3<-lm(effective_species~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data)

summary(model_op3)

ols_plot_cooksd_bar(model_op3)
# no egregious outliers


###  cities included: those with more than 10,000 trees counted
### independent variable: effective_species_givenpop_all 
###### that is, the rarefied or extrapolated effective species count
###### for a tree population = median of 37,000 trees

model_op4<-lm(effective_species_givenpop_all~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data%>%
                filter(number_trees_filtered>10000))

summary(model_op4)

ols_plot_cooksd_bar(model_op4)


###  cities included: those with >50% spatial coverage (and therefore, lat/lon coordinates)
### independent variable: effective_species_givenpop_all
###### that is, the rarefied or extrapolated effective species count
###### for a tree population = median of 37,000 trees

model_op5<-lm(effective_species_givenpop_all~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data%>%
                filter(percent_cells_empty<0.5))

summary(model_op5)

ols_plot_cooksd_bar(model_op5)


###  cities included: those with >0.995 sample coverage as calculated by
###### iNEXT
### independent variable: effective_species_givenpop_all
###### that is, the rarefied or extrapolated effective species count
###### for a tree population = median of 37,000 trees

model_op6<-lm(effective_species_givenpop_all~
                Comp.1:Comp.2+
                Comp.1+ tree_city_USA,
              data=all_data%>%
                filter(samplecoverage_estimate_all>0.995))

summary(model_op6)

ols_plot_cooksd_bar(model_op6)

####################################################################
###
###  Save results of models
###
####################################################################

### Four models to report
models<-list(model_op1,
             model_op2,
             model_op3,
             model_op4,
             model_op5,
             model_op6)

### get coefficients and p values for each
results<-list()

for (i in 1:length(models)){
  mymodel<-models[[i]]
  coefs<-rownames(as.data.frame(summary(mymodel)$coef))
  # results[[i]]<-matrix(NA,nrow=length(coefs),ncol=8)
  results[[i]]<-matrix(NA,nrow=length(coefs),ncol=7)
  
  colnames(results[[i]])<-c(
                            "AIC","AdjR2",
                            # "equation",
                            "coef","estimate",
                       "confint","pvalue","N_cities")
  # results[[i]][1,"equation"]<-paste(mymodel$call[2])
  results[[i]][1,"AIC"]<-round(AIC(mymodel),2)
  results[[i]][1,"AdjR2"]<-round(summary(mymodel)$ adj.r.squared,2)
  results[[i]][1,"N_cities"]<-nobs(mymodel)
  
  for (j in 1:length(coefs)){
    # coef
    results[[i]][j,"coef"]<-coefs[j]
    # estimate
    results[[i]][j,"estimate"]<-round(summary(mymodel)$coef[coefs[j],"Estimate"],2)
    # confidence interval
    right<-round(summary(mymodel)$coef[coefs[j],"Estimate"]+
                  2*summary(mymodel)$coef[coefs[j],"Std. Error"],
                2)
    left<-round(summary(mymodel)$coef[coefs[j],"Estimate"]-
                   2*summary(mymodel)$coef[coefs[j],"Std. Error"],
                 2)
    
    results[[i]][j,"confint"]<-paste0("[",left,", ", right,"]")
    # p value
    results[[i]][j,"pvalue"]<-signif(summary(mymodel)$coef[coefs[j],"Pr(>|t|)"],2)
  }
}


results_pretty<-do.call(rbind, results)

results_pretty<-as.data.frame(results_pretty)

results_pretty[(results_pretty$coef=="(Intercept)"), "pvalue"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "confint"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "estimate"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "coef"] <- ""
results_pretty[is.na(results_pretty)]<-""
results_pretty
write.csv(results_pretty,"ModelResults_Effecive_Species.csv")


######################################################################
##
## Max abundance single species vs. 
## effective species count correlation
## plot residuals
##
######################################################################

# test for correlation
cor.test (all_data$max_abundance_most_common_species, 
          all_data$effective_species, method = "p")

cor.test (all_data$max_abundance_most_common_species, 
          all_data$effective_species_asymest_all, method = "p")

####################################################################
####################################################################
####################################################################
###
###  Percent Native Across Cities
###
####################################################################
####################################################################
####################################################################

####################################################################
###
###  Identify the best model by comparing models with different variables
###
####################################################################

beta1<-betareg(percent_native_trees~
                Comp.1+
                Comp.2+
                Comp.1:Comp.2,
                # log(number_trees)+
                # tree_city_USA+
                # city_age_2021+
                # tree_city_USA:city_age_2021,
                 data=all_data)
summary(beta1)
AIC(beta1)

beta2<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 Comp.1:Comp.2+
               log(number_trees),
               # tree_city_USA+
               # city_age_2021+
               # tree_city_USA:city_age_2021,
               data=all_data)

lrtest(beta1,beta2)
# big difference adding number trees

beta3<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 Comp.1:Comp.2+
                 # log(number_trees),
               tree_city_USA,
               # city_age_2021+
               # tree_city_USA:city_age_2021,
               data=all_data)

lrtest(beta1,beta3)
# no difference adding tree city.

beta4<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 Comp.1:Comp.2+
                 # log(number_trees),
                 # tree_city_USA,
               city_age_2021,
               # tree_city_USA:city_age_2021,
               data=all_data)

lrtest(beta1,beta4)
# big difference adding city age

beta5<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 Comp.1:Comp.2+
                 # log(number_trees)
                 # city_age_2021,
               tree_city_USA:city_age_2021,
               data=all_data)

lrtest(beta5,beta4)
# again tree city makes no difference

beta6<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 Comp.1:Comp.2+
                 log(number_trees)+
                 city_age_2021,
               data=all_data)

lrtest(beta1,beta6)
## 6 is much better than 1

beta7<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 log(number_trees)+
                 city_age_2021,
               data=all_data)

lrtest(beta6,beta7)
# environment interaction term is making no difference

####################################################################
###
###  Run final model, under a variety of sensitivity tests
###
####################################################################

####################################################################
###  Cities included: all
####################################################################

beta_final<-betareg(percent_native_trees~
                 Comp.1+
                 Comp.2+
                 log(number_trees)+
                 city_age_2021,
               data=all_data)


# summary(beta_final)
# AIC(beta_final)
# plot(beta_final)
# beta_final$pseudo.r.squared

## notice outliers-- Honolulu and Miami

####################################################################
###  Cities included: all except Honolulu and Miami
####################################################################
beta_final_nooutliers<-betareg(percent_native_trees~
                      Comp.1+
                      Comp.2+
                      log(number_trees)+
                      city_age_2021,
                    data=all_data%>%
                      filter(filename_city!="Honolulu")%>%
                      filter(filename_city!="Miami"))

# summary(beta_final_nooutlier)
# AIC(beta_final_nooutlier)
# plot(beta_final_nooutlier)
# beta_final_nooutlier$pseudo.r.squared

####################################################################
###  Cities included: all with more than 10,000 identified trees
####################################################################
beta_final_populationcutoff<-betareg(percent_native_trees~
                                Comp.1+
                                Comp.2+
                                log(number_trees)+
                                city_age_2021,
                              data=all_data%>%
                                filter(number_trees_filtered>10000))

# summary(beta_final_populationcutoff)
# AIC(beta_final_populationcutoff)
# plot(beta_final_populationcutoff)
# beta_final_populationcutoff$pseudo.r.squared

####################################################################
###  Cities included: all with more than .995 sample completeness
###  as calculated by iNext
####################################################################
beta_final_samplecoverage<-betareg(percent_native_trees~
                                      Comp.1+
                                      Comp.2+
                                      log(number_trees)+
                                      city_age_2021,
                                    data=all_data%>%
                                      filter(samplecoverage_estimate_all>0.995))

# summary(beta_final_samplecoverage)
# AIC(beta_final_samplecoverage)
# plot(beta_final_samplecoverage)
# beta_final_samplecoverage$pseudo.r.squared

####################################################################
###  Cities included: all with more than 50% spatial coverage (and
###  thus also with latitude and longitude coordinates)
####################################################################
beta_final_spatialcoverage<-betareg(percent_native_trees~
                                       Comp.1+
                                       Comp.2+
                                       log(number_trees)+
                                       city_age_2021,
                                     data=all_data%>%
                                       filter(percent_cells_empty<0.5))

# summary(beta_final_spatialcoverage)
# AIC(beta_final_spatialcoverage)
# plot(beta_final_spatialcoverage)
# beta_final_spatialcoverage$pseudo.r.squared

### models to report
models<-list(beta_final,
             beta_final_nooutliers,
             beta_final_populationcutoff,
             beta_final_spatialcoverage,
             beta_final_samplecoverage)

### get coefficients and p values for each
results<-list()

for (i in 1:length(models)){
  mymodel<-models[[i]]
  coefs<-rownames(as.data.frame(summary(mymodel)$coef))
  results[[i]]<-matrix(NA,nrow=length(coefs),ncol=10)
  colnames(results[[i]])<-c(
    "AIC","Pseudo_R2","loglik",
    "coef","estimate",
    "confint","odds_ratio",
    "confint_odds_ratio","pvalue","n_cities")
  results[[i]][1,"AIC"]<-round(AIC(mymodel),2)
  results[[i]][1,"Pseudo_R2"]<-round(summary(mymodel)$pseudo.r.squared,2)
  results[[i]][1,"loglik"]<-round(summary(mymodel)$loglik,2)
  results[[i]][1,"n_cities"]<-nobs(mymodel)
  
  for (j in 1:length(coefs)){
    # coef
    results[[i]][j,"coef"]<-coefs[j]
    # estimate
    results[[i]][j,"estimate"]<-signif(summary(mymodel)$coef$mean[coefs[j],"Estimate"],2)
    results[[i]][j,"odds_ratio"]<-round(exp(summary(mymodel)$coef$mean[coefs[j],"Estimate"]),4)
    
    # confidence interval
    right<-signif(summary(mymodel)$coef$mean[coefs[j],"Estimate"]+
                   2*summary(mymodel)$coef$mean[coefs[j],"Std. Error"],
                 2)
    left<-signif(summary(mymodel)$coef$mean[coefs[j],"Estimate"]-
                  2*summary(mymodel)$coef$mean[coefs[j],"Std. Error"],
                2)
    
    results[[i]][j,"confint"]<-paste0("[",left,", ", right,"]")
    
    right_OR<-signif(exp(summary(mymodel)$coef$mean[coefs[j],"Estimate"]+
                    2*summary(mymodel)$coef$mean[coefs[j],"Std. Error"]),
                  4)
    left_OR<-signif(exp(summary(mymodel)$coef$mean[coefs[j],"Estimate"]-
                   2*summary(mymodel)$coef$mean[coefs[j],"Std. Error"]),
                 4)
    
    results[[i]][j,"confint_odds_ratio"]<-paste0("[",left_OR,", ", right_OR,"]")
    
    # p value
    results[[i]][j,"pvalue"]<-signif(summary(mymodel)$coef$mean[coefs[j],"Pr(>|z|)"],2)
  }
}


results_pretty<-do.call(rbind, results)

results_pretty<-as.data.frame(results_pretty)

results_pretty[(results_pretty$coef=="(Intercept)"), "pvalue"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "confint"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "estimate"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "confint_odds_ratio"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "odds_ratio"] <- ""
results_pretty[(results_pretty$coef=="(Intercept)"), "coef"] <- ""
results_pretty[is.na(results_pretty)]<-""
results_pretty

write.csv(results_pretty, "ModelResults_Percent_Native.csv")

###################################
###################################
##
## Biodiversity all vs biodiversity native
##
###################################
###################################

# observed values
cor.test (all_data$native_effective_species, 
          all_data$effective_species, method = "p")

# rarefied/ extrapolated valeus for given sample size
cor.test (all_data$effective_species_givenpop_native, 
          all_data$effective_species_givenpop_all, method = "p")

# asymptotic estimates
cor.test (all_data$effective_species_asymest_native, 
          all_data$effective_species_asymest_all, method = "p")

####################################################################
####################################################################
####################################################################
###
###  Similarity Scores: how similar are species compositions
###  across cities? Does the environment shape this similarity? 
###  Are native tree communities more or less similar than the
###  entire tree community?
###
####################################################################
####################################################################
####################################################################

# take a look at data
head(similarity_native)
head(similarity_all)
head(similarity_nonnative)

# with all results, add a number of other important columns
chisq_distances_DF<-similarity_all%>%
  left_join(all_data%>%
              dplyr::select(filename_city,state,Lat,Long,Comp.1,Comp.2)%>%
              rename(state1=state,
                     Lat1=Lat,
                     Long1=Long,
                     Comp.1_city1=Comp.1,
                     Comp.2_city1=Comp.2),
            by=c("city1"="filename_city"))%>%
  left_join(all_data%>%
              dplyr::select(filename_city,state,Lat,Long,Comp.1,Comp.2)%>%
              rename(state2=state,
                     Lat2=Lat,
                     Long2=Long,
                     Comp.1_city2=Comp.1,
                     Comp.2_city2=Comp.2),
            by=c("city2"="filename_city"))%>%
  mutate(samestate=ifelse(state1==state2,"yes","no"))%>%
  mutate(hawaii=ifelse(city1=="Honolulu","yes",ifelse(city2=="Honolulu","yes","no")))%>%
  # get environmental distances based on PCA plot
  mutate(enviro_dist=sqrt((Comp.1_city1-Comp.1_city2)^2+
         (Comp.2_city1-Comp.2_city2)^2))

head(chisq_distances_DF)

# get actual distances between cities
chisq_distances_DF$distance<- distHaversine(chisq_distances_DF[ ,c("Long1", "Lat1")],
                                            chisq_distances_DF[ ,c("Long2", "Lat2")])

head(chisq_distances_DF)

max_env_integer<-round(max(chisq_distances_DF$enviro_dist),0)

## now, merge that file with the native and nonnative results
full_chisq_distances_DF<-chisq_distances_DF%>%
  left_join(.,similarity_native,by=c("city1","city2"),suffix=c("","_native"))%>%
  left_join(.,similarity_nonnative,by=c("city1","city2"),suffix=c("","_nonnative"))%>%
## and convert chi squared distance to chi squared similarity for comparisons
  mutate(chisq_similarity=1-chi_squared_distance)%>%
  mutate(chisq_similarity_NATIVE=1-chi_squared_distance_native)%>%
  mutate(chisq_similarity_NONNATIVE=1-chi_squared_distance_nonnative)%>%
  # normalized environmental similarity
  mutate(enviro_similarity=1-(enviro_dist-min(enviro_dist))/max(enviro_dist)-min(enviro_dist))%>%
  # get differences 
  mutate(all_minus_native=chisq_similarity-chisq_similarity_NATIVE)%>%
  mutate(all_minus_nonnative=chisq_similarity-chisq_similarity_NONNATIVE)%>%
  mutate(nonnative_minus_native=chisq_similarity_NONNATIVE-chisq_similarity_NATIVE)

  

head(full_chisq_distances_DF)
summary(full_chisq_distances_DF)

write.csv(full_chisq_distances_DF,"Chisq_comparisons_speciescomposition.csv")
# full_chisq_distances_DF<-read.csv("Chisq_comparisons_speciescomposition.csv")
####################################################################
###  Statistics
####################################################################

## calculate correlation coefficients
native_env_cor<-cor(full_chisq_distances_DF$enviro_similarity, full_chisq_distances_DF$chisq_similarity_NATIVE)  
all_env_cor<-cor(full_chisq_distances_DF$enviro_similarity, full_chisq_distances_DF$chisq_similarity)
native_all_cor<-cor(full_chisq_distances_DF$chisq_similarity_NATIVE, full_chisq_distances_DF$chisq_similarity)

# test for significant correlations    
cor.test (full_chisq_distances_DF$enviro_similarity, full_chisq_distances_DF$chisq_similarity_NATIVE, method = "p")
cor.test (full_chisq_distances_DF$enviro_similarity, full_chisq_distances_DF$chisq_similarity, method = "p")

# use cocor web interface to compare these dependent, overlapping correlations
cocor_output<-cocor.dep.groups.overlap(r.jk=native_env_cor, r.jh=all_env_cor, r.kh=native_all_cor,
                         n=1951, alternative="two.sided", alpha=0.05,
                         conf.level=0.95, null.value=0)

# extract Z value and p value
cocor_output@pearson1898$statistic
cocor_output@pearson1898$p.value


# check that difference is normal
shapiro.test(full_chisq_distances_DF$nonnative_minus_native)
plot(density(full_chisq_distances_DF$nonnative_minus_native))

# check the difference between all and native only
t.test(full_chisq_distances_DF$chisq_similarity ,
       full_chisq_distances_DF$chisq_similarity_NATIVE,
       paired = TRUE, alternative = "two.sided")

wilcox.test(full_chisq_distances_DF$chisq_similarity_NATIVE,
            full_chisq_distances_DF$chisq_similarity ,
            paired = TRUE, alternative = "two.sided")

####################################################################
####################################################################
####################################################################
###
###  Park vs. Urban Forests
###
####################################################################
####################################################################
####################################################################

########### percent native

# check that difference is normal
shapiro.test(park_vs_urban$percent_native_park-park_vs_urban$percent_native_urban)
plot(density(park_vs_urban$percent_native_park-park_vs_urban$percent_native_urban))

# test difference
tt<-t.test(park_vs_urban$percent_native_park,
       park_vs_urban$percent_native_urban,
       paired = TRUE, alternative = "two.sided")

wilcox.test(park_vs_urban$percent_native_park,
            park_vs_urban$percent_native_urban,
            paired = TRUE, alternative = "two.sided")

paste0("t=",signif(tt$statistic,2),", ",
       "p=",signif(tt$p.value,2), ", ",
       "95% CI=[",signif(tt$conf.int[1],2),", ",signif(tt$conf.int[2],2),"]", ", ",
       "mean diff. = ", signif(tt$estimate,2))

########### max abundance

# check that difference is normal
shapiro.test(park_vs_urban$max_abundance_most_common_species_park-park_vs_urban$max_abundance_most_common_species_urban)
plot(density(park_vs_urban$max_abundance_most_common_species_park-park_vs_urban$max_abundance_most_common_species_urban))

# test difference
tt<-t.test(park_vs_urban$max_abundance_most_common_species_park,
       park_vs_urban$max_abundance_most_common_species_urban,
       paired = TRUE, alternative = "two.sided")

wilcox.test(park_vs_urban$max_abundance_most_common_species_park,
            park_vs_urban$max_abundance_most_common_species_urban,
            paired = TRUE, alternative = "two.sided")

paste0("t=",signif(tt$statistic,2),", ",
       "p=",signif(tt$p.value,2), ", ",
       "95% CI=[",signif(tt$conf.int[1],2),", ",signif(tt$conf.int[2],2),"]", ", ",
       "mean diff. = ", signif(tt$estimate,2))


########### biodiversity

#####################################################
## first, observed expected species values
#####################################################
sensitivity_conditions<-c("observed expected species number",
                          "expected species number for a given population (smaller of the two)",
                          "asymptotic estimate of expected species numbers")

for (condition in sensitivity_conditions){
  if (condition == "observed expected species number"){
    PARK<-park_vs_urban$effective_species_park
    URBAN<-park_vs_urban$effective_species_urban
  } else if (condition == "expected species number for a given population (smaller of the two)"){
    PARK<-park_vs_urban$effective_species_givenpop_park
    URBAN<-park_vs_urban$effective_species_givenpop_urban
  } else if (condition == "asymptotic estimate of expected species numbers") {
    PARK<-park_vs_urban$effective_species_asymest_park
    URBAN<-park_vs_urban$effective_species_asymest_urban
  } else print("Conditions were not met.")

  # check that difference is normal
  shapiro.test(PARK-URBAN)
  # plot(density(PARK-URBAN))
  
  # test difference
  tt<-t.test(PARK,
         URBAN ,
         paired = TRUE, alternative = "two.sided")
  
  wilcox.test(PARK,
              URBAN,
              paired = TRUE, alternative = "two.sided")
  
  print(paste0("For ", condition, ": ",
        "t=",signif(tt$statistic,2),", ",
         "p=",signif(tt$p.value,2), ", ",
         "95% CI=[",signif(tt$conf.int[1],3),", ",signif(tt$conf.int[2],3),"]", ", ",
         "mean diff. = ", signif(tt$estimate,3)))
}

