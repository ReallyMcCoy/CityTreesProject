# this file reads in the raw datasheets, 63 city files where every row is 
# a tree with information about that tree, and does two things. First, 
# it generates a summary .csv with city-specific information on nativity,
# biodiversity, environmental variables, social variables, and more. 
# Second, it calculates weighted comparisons of species compositions between cities.

# load packages
library("dplyr")
library("ggplot2")
library("stringr")
library("maps")
library("totalcensus")
library("raster")
library("mapdata")
library("beepr")
library("taxize")
library("analogue")
library("iNEXT")
library("geosphere")

# set up our directories
home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis'
dir_rawsheets <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Analysis/Final Spreadsheets'
dir_figures <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Figures'
setwd(home_dir)

# read basic files
city_info<-read.csv("city_information.csv")
social_data<-read.csv("Social_Data_Treecity_Ages.csv")
spatialcoverage_data<-read.csv("SpatialCoverage_Summary_Data.csv")
bonap_native<-read.csv("BONAP_native_taxa_uniquebinomials.csv")
bonap_all<-read.csv("BONAP_all_species_uniquebinomials.csv")

# define functions to calculate confidence intervals
my_confint_lower<-function (data){
  n <- length(!is.na(data))
  mean_value <- mean(data, na.rm=T)
  standard_deviation <- sd(data, na.rm=T)
  standard_error <- standard_deviation / sqrt(n)
  alpha = 0.05
  degrees_of_freedom = n - 1
  t_score = qt(p=alpha/2, df=degrees_of_freedom,lower.tail=F)
  margin_error <- t_score * standard_error
  mean_value - margin_error
}

my_confint_higher<-function (data){
  n <- length(!is.na(data))
  mean_value <- mean(data, na.rm=T)
  standard_deviation <- sd(data, na.rm=T)
  standard_error <- standard_deviation / sqrt(n)
  alpha = 0.05
  degrees_of_freedom = n - 1
  t_score = qt(p=alpha/2, df=degrees_of_freedom,lower.tail=F)
  margin_error <- t_score * standard_error
  mean_value + margin_error
}

########################################################################
########################################################################
########################################################################
##
## Generate summary .csv with city-specific information on nativity, biodiversity,
## environmental variables, social variables, and more.
##
########################################################################
########################################################################
########################################################################

## make a blank list to fill it in with dataframes
LIST_NATIVE<-list()

setwd(dir_rawsheets)
all_files<-list.files(pattern = ".csv$")

##################################
###
### Get list of native or not within each city, and counts
###
##################################
for (i in 1:length(all_files)) {

  ## read data
  data<-read.csv(all_files[i])
  if ("scientific_name" %in% colnames(data)) {
    ### stuff
    summary<-data%>%
      #filter(nonmatch==FALSE)%>%
      dplyr::select(scientific_name,state,city,native)%>%
      filter(scientific_name!="")%>%
      group_by(scientific_name,native)%>%
      summarise(n=n())
    
    ############
    ###
    ### Label as "unique" genus-only rows where there are not other species of that genus
    ###
    ############
    
    ## count words in species name
    summary$word_count<-str_count(summary$scientific_name, '\\w+')
    
    ## make list of genera
    genusonlylist<-summary%>%filter(word_count==1)
    speciesonlylist<-summary%>%filter(word_count==2)
    genusonlylist$unique_genus="NA"
    genusonlylist
    
    for (j in 1:nrow(genusonlylist)){
      ## select each genus-only scientific name
      genus=genusonlylist$scientific_name[j]
      ## generate regex search term
      genus_at_start=paste0("^",genus," ",sep="")
      ## count other instances in full dataset of species who share that genus 
      count_genus<-sum(str_count(summary$scientific_name, pattern = genus_at_start))
      ## label with unique or duplicate
      ifelse(count_genus==0,genusonlylist$unique_genus[j]<-"unique",genusonlylist$unique_genus[j]<-"duplicate")
    }
    speciesonlylist<-speciesonlylist%>%
      mutate(unique_genus="species")
    ## bind the "unique" rows back to the dataset
    # genus_to_keep<-genusonlylist%>%filter(unique_genus=="unique")%>%
    #   dplyr::select(-unique_genus)
    alldata<-rbind(speciesonlylist,genusonlylist)%>%
      dplyr::select(-word_count)
    LIST_NATIVE[[all_files[i]]]<-alldata
  }
}
beep()
length(LIST_NATIVE)
LIST_NATIVE[[1]]

#############################
###
### for every city, calculate measures of diversity for whole city population and
### measures of diversity for native trees
###
#############################
setwd(home_dir)

### get list of state names
state_list<-unique(bonap_native$state)

### view city specific information
head(city_info)

## prepare output file
diversity_output<-matrix(nrow=length(LIST_NATIVE),ncol=71)
colnames(diversity_output)<-c("filename_city",
                              "city_pretty",
                              "state",
                              "most_common_species",
                              "most_common_genus",
                              "Lat",
                              "Long",
                              "population",
                              "population_rank",
                              "number_trees",
                              "number_species",
                              "number_trees_filtered",
                              "Shannon_Wiener_Index",
                              "effective_species",
                              "max_abundance_most_common_species",
                              "max_abundance_most_common_genus",
                              "native_number_species",
                              "native_number_trees",
                              "native_Shannon_Wiener_Index",
                              "native_effective_species",
                              "number_trees_known_native_status",
                              "percent_native_trees",
                              "state_number_all_observed_species",
                              "state_number_native_species",
                              "shared_species_city_statenative",
                              "beta_diversity_city_statenative",
                              "nonnative_trees_NO_native_congener",
                              "nonnative_trees_YES_native_congener",
                              "nonnative_species_NO_native_congener",
                              "nonnative_species_YES_native_congener",
                              "nonnative_trees_PERCENTWITH_native_congeners",
                              "nonnative_species_PERCENTWITH_native_congeners",
                              "state_land_area_km2",
                              ### iNext 
                              "number_species_iNext_all",
                              "number_species_asymest_all",
                              "number_species_asymest_SE_all",
                              "number_species_asymest_CIlower_all",
                              "number_species_asymest_CIhigher_all",
                              "effective_species_iNext_all",
                              "effective_species_asymest_all",
                              "effective_species_asymest_SE_all",
                              "effective_species_asymest_CIlower_all",
                              "effective_species_asymest_CIhigher_all",
                              "number_species_givenpop_all",
                              "number_species_givenpop_method_all",
                              "number_species_givenpop_CIlower_all",
                              "number_species_givenpop_CIhigher_all",
                              "effective_species_givenpop_all",
                              "effective_species_givenpop_method_all",
                              "effective_species_givenpop_CIlower_all",
                              "effective_species_givenpop_CIhigher_all",
                              "samplecoverage_estimate_all",
                              "number_species_iNext_native",
                              "number_species_asymest_native",
                              "number_species_asymest_SE_native",
                              "number_species_asymest_CIlower_native",
                              "number_species_asymest_CIhigher_native",
                              "effective_species_iNext_native",
                              "effective_species_asymest_native",
                              "effective_species_asymest_SE_native",
                              "effective_species_asymest_CIlower_native",
                              "effective_species_asymest_CIhigher_native",
                              "number_species_givenpop_native",
                              "number_species_givenpop_method_native",
                              "number_species_givenpop_CIlower_native",
                              "number_species_givenpop_CIhigher_native",
                              "effective_species_givenpop_native",
                              "effective_species_givenpop_method_native",
                              "effective_species_givenpop_CIlower_native",
                              "effective_species_givenpop_CIhigher_native",
                              "samplecoverage_estimate_native")

# below, in order to compare cities of different size, we must extrapolate what their diversity measures
# would be for a standard population size. 
# here we define that standard population size.
median_tree_pop<-37000
median_tree_pop_native<-10000
pop_size <- setNames(c(median_tree_pop,
                       median_tree_pop_native), 
                     c("all","native"))


## calculate diversity measures
for (i in 1:length(LIST_NATIVE)) {
  data_all<-LIST_NATIVE[[i]]
  ##############################################
  ##
  ## All trees: Diversity Measures
  ##
  ##############################################
  data_filter<-data_all%>%
    # keep only genera for which they are unique (to get accurate diversity measures)
    filter(unique_genus!="duplicate")
  data<-data_filter%>%
    # get frequency values
    mutate(frequency=n/sum(data_filter$n))%>%
    # prepare for shannon_wiener
    mutate(freq_ln_freq=-1*frequency*log(frequency))
  ## filename
  diversity_output[i,"filename_city"]<-strsplit(names(LIST_NATIVE)[i], '_')[[1]][1]
  ## number of species
  diversity_output[i,"number_species"]<-nrow(data)
  ## number of trees included (with the limitation of excluding nonmatches, genuses duplicated elsewhere, etc)
  diversity_output[i,"number_trees_filtered"]<-sum(data$n)
  ## shannon weiner
  shannon_wiener <- sum(data$freq_ln_freq)
  diversity_output[i,"Shannon_Wiener_Index"]<-shannon_wiener
  ## exp (shannon wiener)
  diversity_output[i,"effective_species"]<-exp(shannon_wiener)
  ## most common species
  diversity_output[i,"most_common_species"]<-data$scientific_name[which.max(data$frequency)]
  diversity_output[i,"max_abundance_most_common_species"]<-max(data$frequency)
  ## most common genus
  ## build off of all genera, not just unique genera
  data_genera<-data_all ## this includes ALL genera
  data_genera$genus<-str_split_fixed(data_genera$scientific_name,' ',n=2)[,1]
  data_genera<-data_genera%>%group_by(genus)%>%
    summarize(count=sum(n))
  data_genera<-data_genera%>%
    mutate(frequency=count/sum(data_genera$count))
  diversity_output[i,"most_common_genus"]<-data_genera$genus[which.max(data_genera$frequency)]
  diversity_output[i,"max_abundance_most_common_genus"]<-max(data_genera$frequency)
  ##############################################
  ##
  ## Native data only: Diversity Measures
  ##
  ##############################################
  native_data_all<-data_all%>%
    filter(native=="naturally_occurring")
  native_data<-native_data_all%>%
    # get frequency values
    mutate(frequency=n/sum(native_data_all$n))%>%
    # prepare for shannon_wiener
    mutate(freq_ln_freq=-1*frequency*log(frequency))
  # number native species
  diversity_output[i,"native_number_species"]<-nrow(native_data)
  ## number of native trees included (with the limitation of excluding nonmathches, genuses duplicated elsewhere, etc)
  diversity_output[i,"native_number_trees"]<-sum(native_data$n)
  ## shannon weiner
  shannon_wiener_native <- sum(native_data$freq_ln_freq)
  diversity_output[i,"native_Shannon_Wiener_Index"]<-shannon_wiener_native
  ## exp (shannon wiener)
  diversity_output[i,"native_effective_species"]<-exp(shannon_wiener_native)
  ## Exclude species for which we have "no info"
  status_known_data<-data_all%>%
    filter(native!="no_info")
  ## total trees for which we know native status
  diversity_output[i,"number_trees_known_native_status"]<-sum(status_known_data$n)
  ##############################################
  ##
  ## Beta Diversity between City All Species and State Native Species
  ##
  ##############################################
  ## get list of native species in state
  mycity_filename<-strsplit(names(LIST_NATIVE)[i], '_')[[1]][1]
  mystate<-(city_info%>%filter(filename_city==mycity_filename))$state
  mycitypretty<-(city_info%>%filter(filename_city==mycity_filename))$city_pretty
  Lat<-(city_info%>%filter(filename_city==mycity_filename))$Lat
  Long<-(city_info%>%filter(filename_city==mycity_filename))$Long
  Population_Rank<-(city_info%>%filter(filename_city==mycity_filename))$rank
  Population<-(city_info%>%filter(filename_city==mycity_filename))$Population
  state_land_area<-(city_info%>%filter(filename_city==mycity_filename))$land_area_km2
  native_state_list<-(bonap_native%>%filter(state==mystate))$scientific_name
  ## save pretty city name
  diversity_output[i,"city_pretty"]<-mycitypretty
  ## calculate how many species are shared
  shared_count<- sum(data_all$scientific_name %in% native_state_list)
  ## save @ native species in that city's state
  state_native_count<-length(native_state_list)
  diversity_output[i,"state_number_native_species"]<-state_native_count
  ## save # species shared between city and native state
  diversity_output[i,"shared_species_city_statenative"]<-shared_count
  ## save state name
  diversity_output[i,"state"]<-mystate
  ## save state number all observed species
  all_state_list<-(bonap_all%>%filter(state==mystate))$scientific_name
  state_all_count<-length(all_state_list)
  diversity_output[i,"state_number_all_observed_species"]<-state_all_count
  ## save other city info
  diversity_output[i,"population"]<-Population
  diversity_output[i,"population_rank"]<-Population_Rank
  diversity_output[i,"Lat"]<-Lat
  diversity_output[i,"Long"]<-Long
  diversity_output[i,"state_land_area_km2"]<-state_land_area
  ##############################################
  ##
  ## Do non-native species have a native congener among that
  ## state's list of native species?
  ##
  ##############################################
  # get list of all native genera with counts of species within genus
  native_congeners<-as.data.frame(str_split_fixed(native_state_list,' ',n=2)[,1])%>%
    `colnames<-`(c("genus"))%>%
    group_by(genus)%>%
    summarize(number_native_congeners=n())
  # get list of nonnative genera with counts
  congener_values <- data_all%>%
    filter(native=="introduced")%>%
    mutate(genus=str_split_fixed(scientific_name,' ',n=2)[,1])%>%
    group_by(genus)%>%
    ## count how many of each genus-- potentially useful later if we want more detailed info about each city
    summarize(number_nonnative=sum(n))%>%
    ## label each row by whether it has a native congener
    mutate(native_congener=(genus %in% native_congeners$genus))%>%
    ## count number non-native species, and number non-native trees, that have a native congenerer
    group_by(native_congener)%>%
    summarize(trees=sum(number_nonnative),species=n())
  diversity_output[i,"nonnative_trees_NO_native_congener"]<-(congener_values%>%filter(native_congener==FALSE))$trees
  diversity_output[i,"nonnative_trees_YES_native_congener"]<-(congener_values%>%filter(native_congener==TRUE))$trees
  diversity_output[i,"nonnative_species_NO_native_congener"]<-(congener_values%>%filter(native_congener==FALSE))$species
  diversity_output[i,"nonnative_species_YES_native_congener"]<-(congener_values%>%filter(native_congener==TRUE))$species
  ## count number non-native trees that have a native congener
  ##############################################
  ##
  ## Get total # all trees
  ##
  ##############################################
  unfiltered_data<-read.csv(paste0("Final Spreadsheets/",names(LIST_NATIVE)[i],sep=''))
  diversity_output[i,"number_trees"]<-nrow(unfiltered_data)
  
  ##############################################
  ##
  ## All trees : Diversity Measures using iNext
  ## including rarefaction and extrapolation
  ##
  ##############################################

  
    for (value in c("all","native")){
      ####################################################################
      ### first, create array of abundance values depending on the condition
      ####################################################################
      
      ### once for all trees, and once for native trees
      ## all trees
      ifelse (value =="all",
              abun<-as.numeric(data$n),
              ## native trees only
              ifelse(value=="native",
                     abun<-as.numeric(native_data$n),
                     print("something went wrong")))
      
      ####################################################################
      ### before going on, check that there are enough species to perform this analysis
      ### we will set the cap at 5 species
      ####################################################################
      if (length(abun)>4) {
        
      
        ####################################################################
        ### second, perform diversity calculations along with statistics for rarefied and extrapolated samples
        ####################################################################
        
        # q=c(0,1) refers to selecting order 0 (species richness) and order 1 (shannon diversity = effective species)
        x<-iNEXT(abun, q=c(0,1), datatype="abundance",nboot=50,
                 # get estimates up to the defined population size we will use for standard comparisons
                 size=c(sum(abun),pop_size[[value]]))
        
        # extract asymptotic diversity estimates along with related statistics
        # note that the column names are going to depend on the value in the for loop so we can
        # programmatically save the data for all trees and native trees
        
        # species richness
        diversity_output[i,paste0("number_species_iNext_",value,sep="")]<-x$AsyEst["Species Richness","Observed"]
        diversity_output[i,paste0("number_species_asymest_",value,sep="")]<-x$AsyEst["Species Richness","Estimator"]
        diversity_output[i,paste0("number_species_asymest_SE_",value,sep="")]<-x$AsyEst["Species Richness","Est_s.e."]
        diversity_output[i,paste0("number_species_asymest_CIlower_",value,sep="")]<-x$AsyEst["Species Richness","95% Lower"]
        diversity_output[i,paste0("number_species_asymest_CIhigher_",value,sep="")]<-x$AsyEst["Species Richness","95% Upper"]
        
        # shannon diversity = effective species number
        diversity_output[i,paste0("effective_species_iNext_",value,sep="")]<-x$AsyEst["Shannon diversity","Observed"]
        diversity_output[i,paste0("effective_species_asymest_",value,sep="")]<-x$AsyEst["Shannon diversity","Estimator"]
        diversity_output[i,paste0("effective_species_asymest_SE_",value,sep="")]<-x$AsyEst["Shannon diversity","Est_s.e."]
        diversity_output[i,paste0("effective_species_asymest_CIlower_",value,sep="")]<-x$AsyEst["Shannon diversity","95% Lower"]
        diversity_output[i,paste0("effective_species_asymest_CIhigher_",value,sep="")]<-x$AsyEst["Shannon diversity","95% Upper"]
        
        # save sample coverage estimate
        
        diversity_output[i,paste0("samplecoverage_estimate_",value,sep="")]<-x$DataInfo[["SC"]]
        
        
        ####################################################################\
        ### third, save the diversity values given a population size that represents
        ### the median population size of all cities rounded to the nearest 1,000
        ####################################################################v

        y<- x$iNextEst%>%filter(m==pop_size[[value]]) #filter m to get estimate for pop size.
        
        # label the rows by which diversity index they represent
        rownames(y)<-paste("order",y$order,sep="")
        
        # extract estimates, where "order 0" represents species richness
        diversity_output[i,paste0("number_species_givenpop_",value,sep="")]<-y["order0","qD"]
        diversity_output[i,paste0("number_species_givenpop_method_",value,sep="")]<-y["order0","method"]
        diversity_output[i,paste0("number_species_givenpop_CIlower_",value,sep="")]<-y["order0","qD.LCL"]
        diversity_output[i,paste0("number_species_givenpop_CIhigher_",value,sep="")]<-y["order0","qD.UCL"]
        
        # extract estimates, where "order 1" represents shannon weiner diversity = effective species number
        diversity_output[i,paste0("effective_species_givenpop_",value,sep="")]<-y["order1","qD"]
        diversity_output[i,paste0("effective_species_givenpop_method_",value,sep="")]<-y["order1","method"]
        diversity_output[i,paste0("effective_species_givenpop_CIlower_",value,sep="")]<-y["order1","qD.LCL"]
        diversity_output[i,paste0("effective_species_givenpop_CIhigher_",value,sep="")]<-y["order1","qD.UCL"]
        

        ####################################################################\
        ### fourth, plot and save rarefaction curves for species richness and shannon diversity = effective species
        ####################################################################
        
        ### note: do this this step, you should run a new iNext as follows:
        # x<-iNEXT(abun, q=c(0,1), datatype="abundance",nboot=50)
        
        
        # plot rarefaction curves
        # plot<-ggiNEXT(x, type=1, se=TRUE, facet.var="none", grey=FALSE,color.var="order")  
        # 
        # # make the plot pretty
        # plot+ggplot2::theme_classic()+
        #   ggplot2::scale_color_manual(values=c("green4","purple2"))+
        #   ggplot2::scale_fill_manual(values=c("green4","purple2"))+
        #   # add title with city name
        #   ggplot2::labs(title=strsplit( names(LIST_NATIVE[i]),"_")[[1]][1])+
        #   # liomit x axis
        #   ggplot2::theme(axis.title = ggplot2::element_blank(),
        #                  axis.text = ggplot2::element_text(size=8),
        #                  plot.title = ggplot2::element_text(vjust = -3,
        #                                                     hjust=0.05,
        #                                                     size=8),
        #                  legend.position="none")
        # 
        # # save figure
        # ggplot2::ggsave(path="../Figures/Rarefaction_Plots",
        #                 paste0(mycitypretty,
        #                        "_RarefactionPlot_Diversity_",
        #                        value,
        #                        ".pdf",sep=""),
        #                 width=1.75,height=1.75,
        #                 units="in",
        #                 useDingbats=FALSE)
      }
    }
  print(paste0("done with ",all_files[i]))
}

beep()
DIVERSITY<-as.data.frame(diversity_output)

## this is a time consumign step, so I recommend saving as a CSV
# write.csv(DIVERSITY,"diversity_rarefaction.csv")
# DIVERSITY<-read.csv("diversity_rarefaction.csv")
# DIVERSITY<-DIVERSITY%>%select(-X)

 ## convert relevant columns to numeric
DIVERSITY[,6:33] <- sapply(DIVERSITY[,6:33],as.numeric)

##############################################
##
## Calculate percent native
##
##############################################
DIVERSITY$percent_native_trees<-DIVERSITY$native_number_trees/DIVERSITY$number_trees_known_native_status

##############################################
##
## Calculate beta diversity comparing city to the list of native species
## from that state
##
##############################################
DIVERSITY$beta_diversity_city_statenative<-
  DIVERSITY$number_species  + 
  DIVERSITY$state_number_native_species -
  2*DIVERSITY$shared_species_city_statenative 

##############################################
##
## Calculate percentage of non-native trees, and species, that have native congeners
## from that state
##
##############################################

## trees
DIVERSITY$nonnative_trees_PERCENTWITH_native_congeners<-
  # yes / (yes + no)
  DIVERSITY$nonnative_trees_YES_native_congener/(DIVERSITY$nonnative_trees_YES_native_congener+
                                                   DIVERSITY$nonnative_trees_NO_native_congener)
### species
DIVERSITY$nonnative_species_PERCENTWITH_native_congeners<-
  # yes / (yes + no)
  DIVERSITY$nonnative_species_YES_native_congener/(DIVERSITY$nonnative_species_YES_native_congener+
                                                     DIVERSITY$nonnative_species_NO_native_congener)
head(DIVERSITY)
tail(DIVERSITY)

####################################################################################
##
##
## STATE
## save a spreadsheet of all states
##
##
####################################################################################

setwd(home_dir)

native<-bonap_native%>%
  group_by(state,code)%>%
  summarize(state_number_native_species=n())

all_by_state<-bonap_all%>%
  group_by(state,code)%>%
  summarize(state_number_all_observed_species=n())%>%
  full_join(native)

write.csv(all_by_state,"State_Specific_Data.csv",row.names=FALSE, fileEncoding = "UTF-8")


#####################################################
###
### Write city-specific data file
###
####################################################

setwd(home_dir)
# write.csv(DIVERSITY,"City_Specific_Data.csv",row.names=FALSE, fileEncoding = "UTF-8")

#############################################################################
#############################################################################
#############################################################################
#############################################################################
###
### BioClim Analysis: environmental variables
###
#############################################################################
#############################################################################
#############################################################################
#############################################################################

## get data
env <- getData("worldclim", var="bio", res=2.5)


env

### label the variables
bioclim_names <-
  c(
    "Annual_Mean_Temp",
    "Mean_Diurnal_Range",
    "Isothermality",
    "Temp_Seasonality",
    "Max_Temp_Warmest Month",
    "Min_Temp_Coldest_Month",
    "Temp_Annual_Range",
    "Mean_Temp_Wettest_Quarter",
    "Mean_Temp_Driest_Quarter",
    "Mean_Temp_Warmest_Quarter",
    "Mean_Temp_Coldest_Quarter",
    "Annual_Precip",
    "Precip_Wettest_Month",
    "Precip_Driest_Month",
    "Precip_Seasonality",
    "Precip_Wettest_Quarter",
    "Precip_Driest_Quarter",
    "Precip_Warmest_Quarter",
    "Precip_Coldest_Quarter"
  )

names(env) <- bioclim_names

### Crop to continental US

cont_USA_long<-c(-124.848974,-66.885444)
cont_USA_lat<-c(49.384358, 24.396308)

buff <- 1   #a buffer of one degree around the raster

xmin <- cont_USA_long[1] - buff
xmax <- cont_USA_long[2] + buff
ymin <- cont_USA_lat[2] - buff
ymax <- cont_USA_lat[1] + buff

e <- extent(xmin, xmax, ymin, ymax)

envcrop <- crop(env, e)
beep()
### test plot
# plot(envcrop[[1]], main = "Annual Mean Temperature")
# map(
#   'state',
#   xlim = c(xmin, xmax),
#   ylim = c(ymin, ymax),
#   fill = F,
#   add = T
# )

### Crop to Hawaii

Hawaii_long<-c(-178.334698,-154.806773)
Hawaii_lat<-c(28.402123, 18.910361)

buff <- 1   #a buffer of one degree around the raster

xmin <- Hawaii_long[1] - buff
xmax <- Hawaii_long[2] + buff
ymin <- Hawaii_lat[2] - buff
ymax <- Hawaii_lat[1] + buff

e <- extent(xmin, xmax, ymin, ymax)

envcrop_Hawaii <- crop(env, e)
### test plot
# plot(envcrop_Hawaii[[1]], main = "Annual Mean Temperature")
# map(
#   'state',
#   xlim = c(xmin, xmax),
#   ylim = c(ymin, ymax),
#   fill = F,
#   add = T
# )


### Get All Environmental Data

env_all <- data.frame(rasterToPoints(env)) %>%
  rename(.,Long=x,Lat=y)
beep()
head(env_all)

### assign environmental values to each city

ENV_LIST=list()
for (i in 1:nrow(DIVERSITY)){
  env_data_mycity<-env_all%>%
    filter(abs(Long - DIVERSITY$Long[i]) == min(abs(Long - DIVERSITY$Long[i])))%>%
    filter(abs(Lat - DIVERSITY$Lat[i]) == min(abs(Lat - DIVERSITY$Lat[i])))%>%
    rename(.,Env_Long=Long,Env_Lat=Lat)
  ENV_LIST[[DIVERSITY$filename_city[i]]]<-env_data_mycity
}

env_by_city<-bind_rows(ENV_LIST, .id = "filename_city")


### merge with our data
##

alldata<-DIVERSITY%>%
  left_join(env_by_city,by="filename_city")

# write.csv(alldata,"City_Data_Diversity_Enviroment.csv",row.names=FALSE, fileEncoding = "UTF-8")
beep()

################################################
###
### Merge with Social data
### for example, tree city USA age
###
################################################

alldata_social<-alldata%>%
  left_join(social_data,by="filename_city")


# write.csv(alldata_social,"City_Data_Diversity_Enviroment_Social.csv",
#           row.names=FALSE, fileEncoding = "UTF-8")


head(alldata_social)


beep()

################################################
###
### Merge with spatial coverage data
### for example, tree city USA age
###
################################################
spatialcoverage_data_selected<-spatialcoverage_data%>%
  select(percent_cells_empty,
         skew_occupied_cells,
         kurtosis_occupied_cells,
         filename_city)

alldata_social_coverage<-alldata_social%>%
  left_join(spatialcoverage_data_selected,by="filename_city")

alldata_social_coverage

write.csv(alldata_social_coverage,"City_Data_Diversity_Enviroment_Social_Coverage.csv",
          row.names=FALSE, fileEncoding = "UTF-8")


#############################################################################
#############################################################################
#############################################################################
#############################################################################
###
### Get higher-resolution data as a sensitivity test
### will we have the same results for 0.5 resolution?
###
#############################################################################
#############################################################################
#############################################################################
#############################################################################

## get city's coordinates

# coords<-city_info
# 
# ### assign environmental values to each city with res=0.5
# 
# ENV_LIST=list()
# for (y in 1:nrow(coords)){
#   env_hires <- getData("worldclim", var="bio", res=.5,
#                      lat=coords$Lat[y],
#                      lon=coords$Long[y])
# 
#   # insert saved bioclim variable names from above
#   names(env_hires) <- bioclim_names
#   
#   ### Convert data format
#   env_hires_df <- data.frame(rasterToPoints(env_hires)) %>%
#     rename(.,Long=x,Lat=y)
#   
#   env_data_mycity<-env_hires_df%>%
#     filter(abs(Long - coords$Long[y]) == min(abs(Long - coords$Long[y])))%>%
#     filter(abs(Lat - coords$Lat[y]) == min(abs(Lat - coords$Lat[y])))%>%
#     rename(.,Env_Long=Long,Env_Lat=Lat)
#   ENV_LIST[[coords$filename_city[y]]]<-env_data_mycity
# }
# 
# beep()
# env_by_city_hires<-bind_rows(ENV_LIST, .id = "filename_city")
# 
# env_by_city_hires
# 
# write.csv(env_by_city_hires,"Enviroment_HIRES.csv",
#           row.names=FALSE, fileEncoding = "UTF-8")
# 
# alldata_hires<-DIVERSITY%>%
#   left_join(env_by_city_hires,by="filename_city")%>%
#   left_join(social_data,by="filename_city")
# 
# 
# write.csv(alldata_hires,"City_Data_Diversity_Enviroment_Social_HIRES.csv",
#           row.names=FALSE, fileEncoding = "UTF-8")


########################################################################
########################################################################
########################################################################
##
## WEIGHTED DIFFERENCES in species compositions between cities
## 
## calculate chi-squared distance, euclidean distance, and dice-sorenson.
##
########################################################################
########################################################################
########################################################################


# going to do comparisons for all species, and also for only native and only non-native
native_status<-c("naturally_occurring","introduced")
# file_label<-c("native","nonnative","allspecies")

# set up matrices to store values from each subsampling event
chi_squared_distance_boot<-matrix(nrow=50, ncol=1)
euclidean_distance_boot<-matrix(nrow=50, ncol=1)
dice_sorenson_value_boot<-matrix(nrow=50, ncol=1)

# set up table of all possible city combinations
city_pairs<-t(combn(all_files, 2))
head(city_pairs)
colnames(city_pairs)<-c("file_city1","file_city2")

city_pair_results<-matrix(nrow=nrow(city_pairs),ncol=9)
colnames(city_pair_results)<-
  c("chi_squared_distance",
    "chi_squared_confint_lower",
    "chi_squared_confint_higher",
    "euclidean_distance",
    "euclidean_confint_lower",
    "euclidean_confint_higher",
    "dice_sorenson_value",
    "dice_sorenson_confint_lower",
    "dice_sorenson_confint_higher"
    )

comparison_results<-as.data.frame(cbind(city_pairs,city_pair_results))

# save three dataframes
comparison_results_all<-comparison_results
comparison_results_native<-comparison_results
comparison_results_nonnative<-comparison_results

setwd(dir_rawsheets)

############################################
## run the calculations
############################################

for (i in 1:nrow(comparison_results)) {
  # for (i in 1:10) {
        # read in files
        x_raw<-read.csv(comparison_results[i,"file_city1"])
        y_raw<-read.csv(comparison_results[i,"file_city2"])
        
        for (m in 1:3){
        
          # filter species 
          ### when m is 1, run native only
          ### when m is 2, run non-native only  
          ### when m is 3, run full file
          if (m<3){
            x_full<-x_raw%>%
              filter(native==native_status[m])
            y_full<-y_raw%>%
              filter(native==native_status[m])
          } else if (m==3){
            x_full<-x_raw
            y_full<-y_raw
          } else {print ("problem with the m assignments")}
  
          # get number of trees represented
          smaller_tree_pop<-min(nrow(x_full),
                                nrow(y_full))
          
          # randomly subsample the larger dataframe and calculate metrics
          for (rep in 1:50) {
            # if X smaller
            if (nrow(x_full)<nrow(y_full)){
              ## subsample y
              y_comparison<-sample_n(y_full, smaller_tree_pop)
              x_comparison<-x_full
              # if Y smaller
            } else if (nrow(y_full)<nrow(x_full)) {
              ## subsample x
              x_comparison<-sample_n(x_full, smaller_tree_pop)
              y_comparison<-y_full
            } else {print ("problem")}
            
            # summarize them to get species frequencies
            x<-x_comparison%>%group_by(scientific_name)%>%
              summarize(n=n())%>%
              filter(scientific_name!='')%>%
              mutate(X=n/sum(n))%>%
              dplyr::select(-n)
            y<-y_comparison%>%group_by(scientific_name)%>%
              summarize(n=n())%>%
              filter(scientific_name!='')%>%
              mutate(Y=n/sum(n))%>%
              dplyr::select(-n)
            
            comparison<-x%>%
              full_join(y, by= "scientific_name")%>%
              replace(is.na(.), 0)%>%
              mutate(chisq_diff=(X-Y)^2/(X+Y))%>%
              mutate(euclidean_diff=(X-Y)^2)
            
            # calculate comparison metrics
            elements_in_common<-length(intersect(x$scientific_name,
                                                 y$scientific_name))
            total_elements<-nrow(x)+nrow(y)
            chi_squared_distance_boot[rep,1]<-sum(comparison$chisq_diff)/2
            euclidean_distance_boot[rep,1]<-sqrt(sum(comparison$euclidean_diff))
            dice_sorenson_value_boot[rep,1]<-2*elements_in_common/total_elements
          }
          
          # get mean values
          # save mean and confint results in the appropriate dataframe
          ## NATIVE
          if (m==1) {
            comparison_results_native[i,"chi_squared_distance"]<-mean(chi_squared_distance_boot, na.rm=T)
            comparison_results_native[i,"chi_squared_confint_higher"]<-my_confint_higher(chi_squared_distance_boot)
            comparison_results_native[i,"chi_squared_confint_lower"]<-my_confint_lower(chi_squared_distance_boot)
            comparison_results_native[i,"euclidean_distance"]<-mean(euclidean_distance_boot, na.rm=T)
            comparison_results_native[i,"euclidean_confint_higher"]<-my_confint_higher(euclidean_distance_boot)
            comparison_results_native[i,"euclidean_confint_lower"]<-my_confint_lower(euclidean_distance_boot)
            comparison_results_native[i,"dice_sorenson_value"]<-mean(dice_sorenson_value_boot, na.rm=T)
            comparison_results_native[i,"dice_sorenson_confint_higher"]<-my_confint_higher(dice_sorenson_value_boot)
            comparison_results_native[i,"dice_sorenson_confint_lower"]<-my_confint_lower(dice_sorenson_value_boot)
          }
          
          ## NONNATIVE
          if (m==2) {
            comparison_results_nonnative[i,"chi_squared_distance"]<-mean(chi_squared_distance_boot, na.rm=T)
            comparison_results_nonnative[i,"chi_squared_confint_higher"]<-my_confint_higher(chi_squared_distance_boot)
            comparison_results_nonnative[i,"chi_squared_confint_lower"]<-my_confint_lower(chi_squared_distance_boot)
            comparison_results_nonnative[i,"euclidean_distance"]<-mean(euclidean_distance_boot, na.rm=T)
            comparison_results_nonnative[i,"euclidean_confint_higher"]<-my_confint_higher(euclidean_distance_boot)
            comparison_results_nonnative[i,"euclidean_confint_lower"]<-my_confint_lower(euclidean_distance_boot)
            comparison_results_nonnative[i,"dice_sorenson_value"]<-mean(dice_sorenson_value_boot, na.rm=T)
            comparison_results_nonnative[i,"dice_sorenson_confint_higher"]<-my_confint_higher(dice_sorenson_value_boot)
            comparison_results_nonnative[i,"dice_sorenson_confint_lower"]<-my_confint_lower(dice_sorenson_value_boot)
          }
          
          ## ALL
          if (m==3) {
            comparison_results_all[i,"chi_squared_distance"]<-mean(chi_squared_distance_boot, na.rm=T)
            comparison_results_all[i,"chi_squared_confint_higher"]<-my_confint_higher(chi_squared_distance_boot)
            comparison_results_all[i,"chi_squared_confint_lower"]<-my_confint_lower(chi_squared_distance_boot)
            comparison_results_all[i,"euclidean_distance"]<-mean(euclidean_distance_boot, na.rm=T)
            comparison_results_all[i,"euclidean_confint_higher"]<-my_confint_higher(euclidean_distance_boot)
            comparison_results_all[i,"euclidean_confint_lower"]<-my_confint_lower(euclidean_distance_boot)
            comparison_results_all[i,"dice_sorenson_value"]<-mean(dice_sorenson_value_boot, na.rm=T)
            comparison_results_all[i,"dice_sorenson_confint_higher"]<-my_confint_higher(dice_sorenson_value_boot)
            comparison_results_all[i,"dice_sorenson_confint_lower"]<-my_confint_lower(dice_sorenson_value_boot)
          }
        }
        print(paste0("done with i=",i," out of ",nrow(comparison_results))
        )
}

beep()
head(comparison_results_all)
head(comparison_results_native)
head(comparison_results_nonnative)

write.csv(comparison_results_all, 
          paste0(home_dir,"/Species_Composition_Comparisons_ALL.csv"),
          row.names = FALSE)
write.csv(comparison_results_native, 
          paste0(home_dir,"/Species_Composition_Comparisons_NATIVE.csv"),
          row.names = FALSE)
write.csv(comparison_results_nonnative, 
          paste0(home_dir,"/Species_Composition_Comparisons_NONNATIVE.csv"),
          row.names = FALSE)



# write.csv(results_all, paste0(home_dir,"/ChiSquare_Distances_Species_Composition_ALL.csv"))
# write.csv(results_native, paste0(home_dir,"/ChiSquare_Distances_Species_Composition_NATIVE.csv"))
# write.csv(results_nonnative, paste0(home_dir,"/ChiSquare_Distances_Species_Composition_NONNATIVE.csv"))
# 
# write.csv(results_euclidean_all, paste0(home_dir,"/Euclidean_Distances_Species_Composition_ALL.csv"))
# write.csv(results_euclidean_native, paste0(home_dir,"/Euclidean_Distances_Species_Composition_NATIVE.csv"))
# write.csv(results_euclidean_nonnative, paste0(home_dir,"/Euclidean_Distances_Species_Composition_NONNATIVE.csv"))
# 
# write.csv(results_dice_sorenson_all, paste0(home_dir,"/DiceSorenson_Scores_Species_Composition_ALL.csv"))
# write.csv(results_dice_sorenson_native, paste0(home_dir,"/DiceSorenson_Scores_Species_Composition_NATIVE.csv"))
# write.csv(results_dice_sorenson_nonnative, paste0(home_dir,"/DiceSorenson_Scores_Species_Composition_NONNATIVE.csv"))
# 

##########################
##
## Get Dice Sorenson scores for state populations
## of trees, all versus native
##
##
##########################
setwd(home_dir)
head(bonap_all)
head(bonap_native)

state_list<-unique(bonap_all$state)

state_count<-length(state_list)

results_state_ALL<-matrix(nrow=state_count,ncol=state_count)
colnames(results_state_ALL)<-state_list
rownames(results_state_ALL)<-state_list

results_state_NATIVE<-results_state_ALL

for (i in 1:state_count){
  for (j in 1:state_count) {
    
    if (j<i) {
      # BONAP_ALL
      x<-bonap_all%>%
        filter(state==state_list[i])
      y<-bonap_all%>%
        filter(state==state_list[j])

      # dice sorenson
      elements_in_common<-length(intersect(x$scientific_name,
                                           y$scientific_name))
      total_elements<-nrow(x)+nrow(y)
      
      results_state_ALL[i,j]<-2*elements_in_common/total_elements

      # BONAP_NATIVE
      x<-bonap_native%>%
        filter(state==state_list[i])
      y<-bonap_native%>%
        filter(state==state_list[j])
      
      # dice sorenson
      elements_in_common<-length(intersect(x$scientific_name,
                                           y$scientific_name))
      total_elements<-nrow(x)+nrow(y)
      
      results_state_NATIVE[i,j]<-2*elements_in_common/total_elements
      
    }
    
  }
}

write.csv(results_state_ALL, paste0(home_dir,"/DiceSorenson_Scores_States_ALL.csv"))
write.csv(results_state_NATIVE, paste0(home_dir,"/DiceSorenson_Scores_States_NATIVE.csv"))


beep()








################################################################################
###
### NOTES
###
################################################################################


########################################
##
##
##
## Why use effective species #?
##
##
#########################################

### theoretical background
###  http://www.loujost.com/Statistics%20and%20Physics/Diversity%20and%20Similarity/EffectiveNumberOfSpecies.htm
###  http://www.loujost.com/Statistics%20and%20Physics/Diversity%20and%20Similarity/Diversity%20of%20a%20single%20community.htm
###  http://www.loujost.com/Statistics%20and%20Physics/Diversity%20and%20Similarity/How%20to%20compare%20the%20diversities%20of%20two%20communities.htm
###
### Shannon indices are best because they are not biased toward common or rare species
### you should alwys convert diversity indices to effective # of species
### see links above for more details.