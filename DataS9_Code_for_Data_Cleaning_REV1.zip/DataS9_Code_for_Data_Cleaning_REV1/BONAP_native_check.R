## This file reads in data sheets from Sheets_Common_Names_Corrected and, 
## for every tree, adds a label to the "native" column for TRUE, FALSE, or no_info.
## This is completed by referencing the Biota of North America Project data (BONAP).
## All edited files are saved in a folder entitled Sheets_BONAP_Native_Assignments.

library("dplyr")
library("stringr")
library('beepr')
library("ggplot2")

home_dir <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Data Cleaning'
dir_rawsheets <- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Data Cleaning/Sheets_Common_Names_Corrected'
## specify a path for corrected sheets
dir_BONAP<- 'C:/Users/dakot/Dropbox/PC/Documents/Trees/Data Cleaning/Sheets_BONAP_Native_Assignments'
path <-'C:/Users/dakot/Dropbox/PC/Documents/Trees/Data Cleaning//Sheets_BONAP_Native_Assignments'


setwd(home_dir)

# read the data from the Biota of North America project that gives each state's native species.
BONAP_ALL <- read.csv("BONAP_native_taxa_uniquebinomials.csv")

## read the data from the Biota of North America Project and the Global Tree Search
## that gives all recorded species of tree
## this is a stricter list than the taxize database we have already compared
## all tree names to
ALL_RECORDED_SPECIES <- read.csv("TreeList_BONAP_and_GlobalTreeSearch.csv")

# read in csv with state names and their common abbreviations
states <- read.csv("State_Abbreviations.csv")

# read in all files, label each tree as native or not, and save the edited files.
setwd(dir_rawsheets)
all_files<-list.files(pattern = ".csv$")

for (i in 1:length(all_files)) {
  # read data for that city
  data <- read.csv(all_files[i])
  # get cityname
  mycity <- strsplit(all_files[i], '_')[[1]][1]
  # get statename
  mystate <- data$state[1]
  # filter BONAP native plants to be our state
  BONAP<-BONAP_ALL%>%filter(state==mystate)
  # check whether each tree is native to the state
  # label in "native" column
  if ("scientific_name" %in% colnames(data)) {
    data$native=ifelse(data$scientific_name %in% BONAP$scientific_name,
                       "naturally_occurring","introduced")
    ## label cases of no knowledge
    data<-data %>%
      # if we don't have a full scientific name
      mutate(native = ifelse(word_count_name !=2, "no_info", native))%>%
            mutate(native = ifelse(genus_only == "genus_only", "no_info", native))%>%
      ## if scientific name is blank or missing
      mutate(native = ifelse(scientific_name == "", "no_info", native))%>%
      mutate(native = ifelse(scientific_name == "NA", "no_info", native))%>%
      mutate(native = ifelse(scientific_name == "<NA>", "no_info", native))%>%
      mutate(native = ifelse(is.na(scientific_name), "no_info", native))%>%
      ## if scientific name did not match a record in Taxize
      mutate(native = ifelse(nonmatch == "TRUE", "no_info", native))%>%
    ## make a stricter column that requires a match to listed species in
    ## BONAP or GlobalTreeSearch
      mutate(native = ifelse(!(scientific_name %in% ALL_RECORDED_SPECIES$scientific_name),
                                      # if not match to BONAP or GlobalTreeSearch
                                       "no_info",
                                      # else
                                      native))
    
    ## write CSV
    write.csv(data,paste(path,'/',mycity,'_edited_taxize_common_native.csv',sep=''),
                         row.names=FALSE, fileEncoding = "UTF-8")
  }
  # save new CSV
  if (!("scientific_name" %in% colnames(data))) {
    print(allfiles[i],"has no scientific names")
  }
}
beep()

