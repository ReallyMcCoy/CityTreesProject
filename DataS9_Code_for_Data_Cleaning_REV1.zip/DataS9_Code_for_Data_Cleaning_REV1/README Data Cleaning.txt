This README applies to a series of data cleaning code files in R and Python. Before this data cleaning, we acquired 63 city tree inventories from US cities, renamed all column headers, and made other city-specific edits. We saved all data sheets at each step of data cleaning in order to manually check them for unexpected errors. Therefore, raw files proceed through a series of folders as follows: Sheets_To_Clean; Sheets_Data_Misspellings_Corrected; Sheets_Common_Names_Corrected; Sheets_BONAP_Native_Assignments; Sheets_Coordinates_Fixed; Sheets_Columns_Selected. 

1) fix_data_misspellings.ipynb : this file reads in raw datasheets from a folder titled Sheets_To_Clean and corrects typos, corrects misspellings, standardizes units, standardizes all columns, makes other edits, and saves edited files to a folder entitled Sheets_Data_Misspellings_Corrected.

2) taxize_name_corrections.R : this file reads in data sheets from Sheets_Data_Misspellings_Corrected, checks the spelling and formatting of all scientific names and corrects them in comparison to online taxonomy databases, and saves the edited sheets to a folder titled Sheets_Taxize_Name_Corrections.

3) common_name_corrections.R : this files reads in data sheets from Sheets_Taxize_Name_Corrections and -- for all files that only list common names, not scientific names, converts all common names to scientific. All edited files are saved to a folder entitled Sheets_Common_Names_Corrected. 

4) BONAP_native_check.R : this file reads in data sheets from Sheets_Common_Names_Corrected and, for every tree, adds a label to the "native" column for TRUE, FALSE, or no_info. This is completed by referencing the Biota of North America Project data (BONAP). All edited files are saved in a folder entitled Sheets_BONAP_Native_Assignments.

5) add_coordinates.R : this file reads in data sheets from Sheets_BONAP_Native_Assignments. For sheets that do not have latitude and longitude coordinates (but do have a street address), this file adds latitude and longitude coordinates. NOTE: we used a google API to convert addresses to latitude and longitude using the code file get_coordinates.ipynb ; this file only merges our complete files with the address -> lat/long files. Edited files are saved in a folder entitled Sheets_Coordinates_Fixed. 

6) select_columns.R : this file reads in data sheets from Sheets_Coordinates_Fixed and selects the same standardized set of columns for all files. Edited files are saved in a folder entitled Sheets_Columns_Selected. 

